import * as React from "react";

export interface CategoryTabProps {
  children: React.ReactNode;
  /** @default false */
  active?: boolean;
  /** Optional leading icon node. */
  icon?: React.ReactNode;
  onClick?: (e: React.MouseEvent) => void;
  style?: React.CSSProperties;
}

/** Pill tab for filtering the menu by category (Хлеб, Выпечка…). */
export function CategoryTab(props: CategoryTabProps): JSX.Element;
