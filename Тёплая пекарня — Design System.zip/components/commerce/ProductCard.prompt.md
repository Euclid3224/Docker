Catalog product card composing Badge + Price + Button/QuantityControl over a photo.

```jsx
const [qty, setQty] = React.useState(0);
<ProductCard
  name="Хачапури с сыром"
  description="Сочная начинка из сыра в нежном тесте."
  price={75}
  stock={5}
  image="assets/images/bakery-1.jfif"
  quantity={qty}
  onAdd={() => setQty(1)}
  onChange={setQty}
/>
```

Hover lifts the card and zooms the photo. When `stock` is 0 it shows a disabled "Нет в наличии"; when `quantity > 0` the button becomes a caramel stepper capped at `stock`.

**`compact`** (used in the menu grid) makes an elegant tile: no description, a small stock line, and price + a smaller "В корзину" button on one row.

```jsx
<ProductCard compact name="Капучино" price={140} stock={30} image="…" quantity={qty} onAdd={…} onChange={…} />
```
