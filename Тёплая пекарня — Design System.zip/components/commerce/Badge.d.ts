import * as React from "react";

export interface BadgeProps {
  children: React.ReactNode;
  /** @default "success" */
  tone?: "success" | "danger" | "neutral" | "caramel";
  style?: React.CSSProperties;
}

/** Small status pill — stock state, labels. */
export function Badge(props: BadgeProps): JSX.Element;
