import React from "react";

/**
 * Price — formatted rouble price. `pill` (olive chip) or `plain` (caramel text).
 */
export function Price({ value, variant = "pill", style }) {
  const formatted = typeof value === "number"
    ? `${value.toLocaleString("ru-RU")} ₽`
    : value;

  if (variant === "plain") {
    return (
      <span style={{
        fontFamily: "var(--font-body)", fontWeight: "var(--fw-black)",
        fontSize: "var(--text-base)", color: "var(--caramel)", whiteSpace: "nowrap", ...style,
      }}>{formatted}</span>
    );
  }

  return (
    <span style={{
      display: "inline-flex", alignItems: "center", justifyContent: "center",
      minHeight: 34, minWidth: 70, padding: "4px 14px",
      borderRadius: "var(--radius-pill)",
      background: "rgba(111,127,77,0.12)", color: "var(--leaf)",
      fontFamily: "var(--font-body)", fontWeight: 900, fontSize: "var(--text-base)",
      whiteSpace: "nowrap", ...style,
    }}>{formatted}</span>
  );
}
