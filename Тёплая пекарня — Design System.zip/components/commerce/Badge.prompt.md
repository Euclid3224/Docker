Small status pill.

```jsx
<Badge tone="success">В наличии: 12 шт.</Badge>
<Badge tone="danger">Нет в наличии</Badge>
<Badge tone="caramel">Хит</Badge>
```

Tones: `success` (olive — in stock), `danger` (berry — out of stock), `neutral` (milk), `caramel`.
