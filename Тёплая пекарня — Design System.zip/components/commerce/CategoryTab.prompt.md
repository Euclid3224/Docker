Pill tab for filtering the catalog by category.

```jsx
<CategoryTab active>Выпечка</CategoryTab>
<CategoryTab onClick={() => setCat('bread')}>Хлеб</CategoryTab>
```

Active fills caramel/white; inactive is a white pill that tints to milk on hover and lifts slightly.
