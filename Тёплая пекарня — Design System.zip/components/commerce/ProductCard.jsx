import React from "react";
import { Badge } from "./Badge.jsx";
import { Price } from "./Price.jsx";
import { Button } from "../buttons/Button.jsx";
import { QuantityControl } from "../buttons/QuantityControl.jsx";

/**
 * ProductCard — catalog card: image, stock, price, name and an "add to cart"
 * action that flips to a quantity stepper.
 *
 * `compact` (used in the menu grid) drops the description, shrinks the button and
 * lays price + action on one tidy row for a cleaner, more elegant tile.
 */
export function ProductCard({
  name,
  description,
  price,
  image,
  stock = 0,
  quantity = 0,
  compact = false,
  onAdd,
  onChange,
  style,
}) {
  const soldOut = stock <= 0;
  const [hover, setHover] = React.useState(false);

  const action = soldOut ? (
    <Button size="sm" disabled style={{ pointerEvents: "none" }}>Нет</Button>
  ) : quantity > 0 ? (
    <div style={{ width: compact ? 104 : "100%" }}>
      <QuantityControl value={quantity} max={stock} variant={compact ? "soft" : "filled"} onChange={onChange} />
    </div>
  ) : (
    <Button size="sm" fullWidth={!compact} onClick={onAdd}>В корзину</Button>
  );

  return (
    <article
      className="ds-pcard"
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: "flex",
        flexDirection: "column",
        minWidth: 0,
        overflow: "hidden",
        borderRadius: "var(--radius-md)",
        background: "var(--surface-raised)",
        border: "1px solid var(--border-soft)",
        boxShadow: hover ? "var(--shadow-hover)" : "var(--shadow)",
        transform: hover ? "var(--lift-card)" : "none",
        transition: "transform var(--dur) var(--ease), box-shadow var(--dur) var(--ease)",
        fontFamily: "var(--font-body)",
        ...style,
      }}
    >
      <div className="ds-pcard__media" style={{ position: "relative", overflow: "hidden", height: compact ? 150 : 200 }}>
        <img
          src={image}
          alt={name}
          style={{
            display: "block", width: "100%", height: "100%", objectFit: "cover",
            objectPosition: "center 25%",
            filter: soldOut ? "grayscale(0.5) brightness(0.95)" : "none",
            transform: hover && !soldOut ? "scale(1.05)" : "none",
            transition: "transform var(--dur-slow) var(--ease)",
          }}
        />
        {soldOut ? (
          <span style={{
            position: "absolute", top: 10, left: 10,
            padding: "3px 11px", borderRadius: "var(--radius-pill)",
            background: "rgba(39,24,18,0.78)", color: "var(--cream)",
            fontSize: "var(--text-xs)", fontWeight: "var(--fw-black)", lineHeight: 1,
          }}>Нет в наличии</span>
        ) : null}
      </div>

      {compact ? (
        <div className="ds-pcard__body" style={{ display: "flex", flexDirection: "column", flex: 1, padding: "13px 14px 15px", gap: 4 }}>
          <h3 className="ds-pcard__title" style={{
            margin: 0, fontFamily: "var(--font-display)", fontWeight: 600,
            fontSize: "1.32rem", lineHeight: 1.12, color: "var(--text-heading)",
            textWrap: "pretty",
          }}>{name}</h3>
          {!soldOut ? (
            <span style={{ fontSize: "var(--text-xs)", fontWeight: "var(--fw-bold)", color: "var(--leaf)" }}>
              В наличии · {stock} шт.
            </span>
          ) : null}
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10, marginTop: "auto", paddingTop: 10 }}>
            <Price value={price} variant="plain" style={{ fontSize: "1.18rem" }} />
            {action}
          </div>
        </div>
      ) : (
        <div className="ds-pcard__body" style={{ display: "flex", flexDirection: "column", flex: 1, padding: "20px 22px 22px" }}>
          <div className="ds-pcard__meta" style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8, flexWrap: "wrap", marginBottom: 14 }}>
            <Badge tone={soldOut ? "danger" : "success"}>
              {soldOut ? "Нет в наличии" : `В наличии: ${stock} шт.`}
            </Badge>
            <Price value={price} variant="plain" />
          </div>

          <h3 className="ds-pcard__title" style={{
            margin: "0 0 8px", fontFamily: "var(--font-display)", fontWeight: 600,
            fontSize: "var(--text-h3)", lineHeight: "var(--lh-tight)", color: "var(--text-heading)",
          }}>{name}</h3>

          <p className="ds-pcard__desc" style={{
            flex: 1, margin: "0 0 18px", fontSize: "var(--text-sm)",
            lineHeight: "var(--lh-body)", color: "var(--text-body)",
          }}>{description}</p>

          {soldOut ? (
            <Button fullWidth disabled>Нет в наличии</Button>
          ) : quantity > 0 ? (
            <QuantityControl value={quantity} max={stock} onChange={onChange} />
          ) : (
            <Button fullWidth onClick={onAdd}>В корзину</Button>
          )}
        </div>
      )}
    </article>
  );
}
