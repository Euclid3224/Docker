import * as React from "react";

/**
 * Props for the catalog product card.
 * @startingPoint section="Commerce" subtitle="Product card with stock + add to cart" viewport="360x440"
 */
export interface ProductCardProps {
  name: string;
  description: string;
  /** Number (auto-formatted) or ready price string. */
  price: number | string;
  /** Image URL. */
  image: string;
  /** Units in stock. 0 → "Нет в наличии". @default 0 */
  stock?: number;
  /** Units already in cart. >0 swaps the button for a stepper. @default 0 */
  quantity?: number;
  /** Compact menu tile: no description, smaller button, price+action on one row. @default false */
  compact?: boolean;
  /** Called when "В корзину" is pressed. */
  onAdd?: () => void;
  /** Called with the next quantity from the stepper. */
  onChange?: (next: number) => void;
  style?: React.CSSProperties;
}

/** Catalog product card — image, stock badge, price, name, description, add-to-cart. */
export function ProductCard(props: ProductCardProps): JSX.Element;
