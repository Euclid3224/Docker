Formats a number into a rouble price.

```jsx
<Price value={75} />                  {/* olive pill: "75 ₽" */}
<Price value={320} variant="plain" /> {/* caramel text */}
```

Numbers are localised with a thin separator (`1 250 ₽`). Use the `pill` chip in catalog cards, `plain` inline next to a name.
