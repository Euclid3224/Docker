import React from "react";

/**
 * Badge — small status pill. Stock states use leaf (in stock) / berry (out).
 */
export function Badge({ children, tone = "success", style }) {
  const palette = {
    success: { background: "rgba(111,127,77,0.13)", color: "var(--leaf)" },
    danger: { background: "rgba(142,58,44,0.10)", color: "var(--berry)" },
    neutral: { background: "var(--milk)", color: "var(--cocoa)" },
    caramel: { background: "rgba(184,117,56,0.14)", color: "var(--caramel)" },
  }[tone];

  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        minHeight: 30,
        padding: "3px 12px",
        borderRadius: "var(--radius-pill)",
        fontFamily: "var(--font-body)",
        fontSize: "var(--text-xs)",
        fontWeight: "var(--fw-black)",
        lineHeight: 1,
        whiteSpace: "nowrap",
        ...palette,
        ...style,
      }}
    >
      {children}
    </span>
  );
}
