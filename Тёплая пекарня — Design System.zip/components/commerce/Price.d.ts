import * as React from "react";

export interface PriceProps {
  /** Number (auto-formatted to "75 ₽") or a ready string. */
  value: number | string;
  /** "pill" = olive chip; "plain" = caramel text. @default "pill" */
  variant?: "pill" | "plain";
  style?: React.CSSProperties;
}

/** Rouble price — olive pill or plain caramel text. */
export function Price(props: PriceProps): JSX.Element;
