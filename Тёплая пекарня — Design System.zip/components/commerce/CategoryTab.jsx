import React from "react";

/**
 * CategoryTab — pill tab for filtering the menu by category.
 * Active state fills caramel; optional icon node.
 */
export function CategoryTab({ children, active = false, icon, onClick, style }) {
  const base = {
    display: "inline-flex",
    alignItems: "center",
    gap: "8px",
    minHeight: 46,
    padding: "11px 20px",
    borderRadius: "var(--radius-pill)",
    fontFamily: "var(--font-body)",
    fontWeight: "var(--fw-black)",
    fontSize: "var(--text-sm)",
    lineHeight: 1,
    cursor: "pointer",
    transition: "background var(--dur-fast) var(--ease), border-color var(--dur-fast) var(--ease), color var(--dur-fast) var(--ease), transform var(--dur-fast) var(--ease)",
  };

  const state = active
    ? { background: "var(--caramel)", color: "var(--white)", border: "1px solid var(--border-strong)", boxShadow: "var(--shadow-sm)" }
    : { background: "var(--white)", color: "var(--cocoa)", border: "1px solid var(--border-soft)", boxShadow: "var(--shadow-sm)" };

  return (
    <button
      type="button"
      aria-pressed={active}
      onClick={onClick}
      style={{ ...base, ...state, ...style }}
      onMouseEnter={(e) => { if (!active) { e.currentTarget.style.background = "var(--milk)"; } e.currentTarget.style.transform = "translateY(-2px)"; }}
      onMouseLeave={(e) => { if (!active) { e.currentTarget.style.background = "var(--white)"; } e.currentTarget.style.transform = ""; }}
    >
      {icon ? <span aria-hidden="true" style={{ display: "inline-flex" }}>{icon}</span> : null}
      {children}
    </button>
  );
}
