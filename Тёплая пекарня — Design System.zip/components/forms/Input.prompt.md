Labelled text input with a gold focus ring. Set `multiline` for a textarea.

```jsx
<Input label="Ваше имя" name="name" required placeholder="Как к вам обращаться" />
<Input label="Телефон" name="phone" type="tel" placeholder="+7 900 000-00-00" required />
<Input label="Комментарий" name="comment" multiline placeholder="Необязательно" />
```

Always pair with a `label`. Focus turns the border caramel and adds a soft gold glow.
