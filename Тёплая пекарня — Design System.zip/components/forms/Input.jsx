import React from "react";

/**
 * Input — labelled text field used in the pickup-order form.
 * Renders a textarea when `multiline` is set.
 */
export function Input({
  label,
  name,
  type = "text",
  placeholder,
  value,
  defaultValue,
  onChange,
  required = false,
  multiline = false,
  rows = 3,
  style,
  ...rest
}) {
  const field = {
    width: "100%",
    boxSizing: "border-box",
    minHeight: multiline ? undefined : 48,
    padding: "13px 16px",
    borderRadius: "var(--radius-sm)",
    border: "1px solid var(--border-soft)",
    background: "var(--white)",
    color: "var(--text-strong)",
    fontFamily: "var(--font-body)",
    fontSize: "var(--text-base)",
    lineHeight: "var(--lh-body)",
    outline: "none",
    transition: "border-color var(--dur-fast) var(--ease), box-shadow var(--dur-fast) var(--ease)",
    resize: multiline ? "vertical" : undefined,
  };

  const onFocus = (e) => {
    e.currentTarget.style.borderColor = "var(--border-strong)";
    e.currentTarget.style.boxShadow = "0 0 0 3px rgba(216,166,77,0.25)";
  };
  const onBlur = (e) => {
    e.currentTarget.style.borderColor = "var(--border-soft)";
    e.currentTarget.style.boxShadow = "none";
  };

  return (
    <label style={{ display: "grid", gap: "7px", fontFamily: "var(--font-body)", ...style }}>
      {label ? (
        <span style={{ fontSize: "var(--text-sm)", fontWeight: "var(--fw-bold)", color: "var(--text-heading)" }}>
          {label}{required ? <span style={{ color: "var(--danger)" }}> *</span> : null}
        </span>
      ) : null}
      {multiline ? (
        <textarea name={name} placeholder={placeholder} rows={rows} value={value}
          defaultValue={defaultValue} onChange={onChange} required={required}
          style={field} onFocus={onFocus} onBlur={onBlur} {...rest} />
      ) : (
        <input name={name} type={type} placeholder={placeholder} value={value}
          defaultValue={defaultValue} onChange={onChange} required={required}
          style={field} onFocus={onFocus} onBlur={onBlur} {...rest} />
      )}
    </label>
  );
}
