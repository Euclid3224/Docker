import * as React from "react";

export interface InputProps {
  /** Field label shown above the control. */
  label?: string;
  name?: string;
  /** @default "text" */
  type?: string;
  placeholder?: string;
  value?: string;
  defaultValue?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
  /** @default false */
  required?: boolean;
  /** Render a textarea. @default false */
  multiline?: boolean;
  /** Textarea rows. @default 3 */
  rows?: number;
  style?: React.CSSProperties;
}

/** Labelled text field / textarea — used in the pickup-order form. */
export function Input(props: InputProps): JSX.Element;
