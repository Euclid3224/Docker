import React from "react";

/**
 * Wordmark — "Тёплая пекарня" logotype in Cormorant Garamond italic.
 * Variants:
 *   • "type"   — bare logotype: `stacked` (two lines, header) or `inline` (footer)
 *   • "emblem" — centred badge lockup with gold hairline flourishes + tagline
 */
export function Wordmark({
  tone = "dark",
  variant = "type",
  layout = "stacked",
  size = 1,
  tagline = "Свежая выпечка каждый день",
  href, style,
}) {
  const color = tone === "light" ? "var(--cream)" : "var(--cocoa)";
  const flourish = tone === "light" ? "var(--sand)" : "var(--gold)";

  let inner;
  if (variant === "emblem") {
    const rule = (
      <span aria-hidden="true" style={{
        flex: 1, height: 1, minWidth: `${22 * size}px`,
        background: `linear-gradient(90deg, transparent, ${flourish})`,
      }} />
    );
    inner = (
      <span style={{ display: "grid", justifyItems: "center", gap: `${0.5 * size}em`,
        fontFamily: "var(--font-display)", color, textAlign: "center" }}>
        <span style={{ display: "flex", alignItems: "center", gap: `${0.55 * size}em`, width: "100%" }}>
          {rule}
          <span style={{ fontFamily: "var(--font-body)", fontWeight: 800,
            fontSize: `${0.62 * size}rem`, letterSpacing: "0.22em", textTransform: "uppercase",
            color: flourish, whiteSpace: "nowrap" }}>Пекарня</span>
          <span style={{ transform: "scaleX(-1)", display: "flex", flex: 1 }}>{rule}</span>
        </span>
        <span style={{ display: "grid", lineHeight: 0.9, fontStyle: "italic" }}>
          <span style={{ fontSize: `${2.0 * size}rem`, fontWeight: 500 }}>Тёплая</span>
          <strong style={{ fontSize: `${2.7 * size}rem`, fontWeight: 700 }}>пекарня</strong>
        </span>
        {tagline ? (
          <span style={{ fontFamily: "var(--font-body)", fontWeight: 700,
            fontSize: `${0.6 * size}rem`, letterSpacing: "0.14em", textTransform: "uppercase",
            color: tone === "light" ? "var(--text-on-dark)" : "var(--text-muted)" }}>{tagline}</span>
        ) : null}
      </span>
    );
  } else {
    const stacked = layout === "stacked";
    inner = (
      <span style={{
        display: stacked ? "grid" : "inline-flex",
        alignItems: "baseline",
        gap: stacked ? 0 : "0.34em",
        lineHeight: stacked ? 0.92 : 1,
        fontFamily: "var(--font-display)",
        fontStyle: "italic",
        color,
      }}>
        <span style={{ fontSize: `${1.9 * size}rem`, fontWeight: 500 }}>Тёплая</span>
        <strong style={{ fontSize: `${(stacked ? 2.5 : 1.9) * size}rem`, fontWeight: 700 }}>пекарня</strong>
      </span>
    );
  }

  if (href) {
    return (
      <a href={href} aria-label="Тёплая пекарня — на главную"
         style={{ textDecoration: "none", display: "inline-block", ...style }}>
        {inner}
      </a>
    );
  }
  return <span style={style}>{inner}</span>;
}
