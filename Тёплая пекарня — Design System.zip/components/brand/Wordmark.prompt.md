The "Тёплая пекарня" logotype — Cormorant Garamond italic.

```jsx
<Wordmark href="index.html" />                     {/* type, stacked — header */}
<Wordmark variant="emblem" />                      {/* centred badge + tagline */}
<Wordmark tone="light" layout="inline" />          {/* footer on dark */}
```

Two variants. **`type`** (default) is the bare logotype: `stacked` puts "Тёплая" above a bolder "пекарня"; `inline` sets them on one line. **`emblem`** is a centred badge lockup with gold hairline flourishes, an uppercase "Пекарня" kicker and a tagline (override or hide via `tagline`) — use it for hero, packaging, the about block. Use `tone="light"` over dark/photo backgrounds.
