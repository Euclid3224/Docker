import * as React from "react";

export interface WordmarkProps {
  /** Text color for light or dark backgrounds. @default "dark" */
  tone?: "dark" | "light";
  /** "type" = bare logotype; "emblem" = centred badge with flourishes + tagline. @default "type" */
  variant?: "type" | "emblem";
  /** (type only) Two-line stack (header) or single line (footer). @default "stacked" */
  layout?: "stacked" | "inline";
  /** Scale multiplier. @default 1 */
  size?: number;
  /** (emblem only) Tagline under the name; pass "" to hide. @default "Свежая выпечка каждый день" */
  tagline?: string;
  /** Wrap in a link to the homepage. */
  href?: string;
  style?: React.CSSProperties;
}

/** "Тёплая пекарня" logotype in Cormorant Garamond italic. */
export function Wordmark(props: WordmarkProps): JSX.Element;
