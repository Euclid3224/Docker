import * as React from "react";

export interface QuantityControlProps {
  /** Current quantity. @default 1 */
  value?: number;
  /** @default 0 */
  min?: number;
  /** @default 99 */
  max?: number;
  /** Called with the next value when −/+ is pressed. */
  onChange?: (next: number) => void;
  /** "filled" = caramel (product card); "soft" = white (cart line). @default "filled" */
  variant?: "filled" | "soft";
  style?: React.CSSProperties;
}

/** Segmented −/value/+ quantity stepper used in product cards and the cart. */
export function QuantityControl(props: QuantityControlProps): JSX.Element;
