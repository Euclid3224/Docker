import * as React from "react";

/**
 * Props for the primary call-to-action button.
 * @startingPoint section="Buttons" subtitle="Pill CTA — primary / light / ghost" viewport="700x360"
 */
export interface ButtonProps {
  children: React.ReactNode;
  /** Visual style. @default "primary" */
  variant?: "primary" | "light" | "ghost";
  /** @default "md" */
  size?: "sm" | "md" | "lg";
  /** Render as a link instead of a button. */
  href?: string;
  /** Icon node placed before the label. */
  icon?: React.ReactNode;
  /** Icon node placed after the label. */
  iconRight?: React.ReactNode;
  /** Stretch to fill the container width. @default false */
  fullWidth?: boolean;
  /** @default false */
  disabled?: boolean;
  /** @default "button" */
  type?: "button" | "submit" | "reset";
  onClick?: (e: React.MouseEvent) => void;
  style?: React.CSSProperties;
}

/** Primary call-to-action button. Pill-shaped, caramel gradient by default. */
export function Button(props: ButtonProps): JSX.Element;
