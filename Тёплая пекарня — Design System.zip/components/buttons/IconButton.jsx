import React from "react";

/**
 * IconButton — round, icon-only control (close, search, menu).
 * Pass an <img> or inline SVG as children.
 */
export function IconButton({
  children,
  variant = "soft",
  size = 42,
  label,
  onClick,
  type = "button",
  style,
  ...rest
}) {
  const palette = {
    soft: { background: "var(--cream)", color: "var(--cocoa)", border: "1px solid transparent" },
    outline: { background: "var(--white)", color: "var(--cocoa)", border: "1px solid var(--border-soft)" },
    ghost: { background: "transparent", color: "var(--cocoa)", border: "1px solid transparent" },
  }[variant];

  return (
    <button
      type={type}
      aria-label={label}
      onClick={onClick}
      style={{
        display: "grid",
        placeItems: "center",
        width: size,
        height: size,
        borderRadius: "var(--radius-circle)",
        cursor: "pointer",
        fontFamily: "var(--font-body)",
        fontSize: "1.4rem",
        lineHeight: 1,
        transition: "background var(--dur-fast) var(--ease), transform var(--dur-fast) var(--ease)",
        ...palette,
        ...style,
      }}
      onMouseEnter={(e) => { e.currentTarget.style.background = "var(--milk)"; }}
      onMouseLeave={(e) => { e.currentTarget.style.background = palette.background; }}
      {...rest}
    >
      {children}
    </button>
  );
}
