Round, icon-only button for header and drawer actions.

```jsx
<IconButton label="Открыть поиск"><img src="assets/icons/icon-search.svg" alt="" width="22" height="22" /></IconButton>
<IconButton variant="ghost" label="Закрыть корзину">×</IconButton>
```

Always pass `label` for accessibility. Variants: `soft` (cream fill, default), `outline`, `ghost`. Hover tints to milk.
