import React from "react";

/**
 * QuantityControl — segmented −/value/+ stepper.
 * Caramel "add" style when filled; used inside product cards and the cart.
 */
export function QuantityControl({
  value = 1,
  min = 0,
  max = 99,
  onChange,
  variant = "filled",
  style,
}) {
  const filled = variant === "filled";
  const dec = () => onChange && onChange(Math.max(min, value - 1));
  const inc = () => onChange && onChange(Math.min(max, value + 1));

  const wrap = filled
    ? {
        background: "linear-gradient(135deg, var(--caramel), var(--caramel-deep))",
        color: "var(--white)",
        boxShadow: "var(--shadow-button)",
        minHeight: 48,
        gridTemplateColumns: "52px minmax(0,1fr) 52px",
      }
    : {
        background: "var(--white)",
        color: "var(--cocoa)",
        border: "1px solid var(--border-soft)",
        minHeight: 38,
        gridTemplateColumns: "38px minmax(0,1fr) 38px",
      };

  const btn = {
    border: 0,
    background: filled ? "rgba(255,255,255,0.08)" : "var(--cream)",
    color: "inherit",
    font: "inherit",
    fontSize: "1.3rem",
    fontWeight: "var(--fw-black)",
    cursor: "pointer",
    display: "grid",
    placeItems: "center",
  };

  return (
    <div
      style={{
        display: "grid",
        alignItems: "center",
        overflow: "hidden",
        borderRadius: "var(--radius-pill)",
        fontFamily: "var(--font-body)",
        ...wrap,
        ...style,
      }}
    >
      <button type="button" aria-label="Убрать одну" onClick={dec} disabled={value <= min}
        style={{ ...btn, opacity: value <= min ? 0.45 : 1 }}>−</button>
      <strong style={{
        display: "grid", placeItems: "center", fontSize: "var(--text-base)",
        borderLeft: filled ? "1px solid rgba(255,255,255,0.16)" : "1px solid var(--border-soft)",
        borderRight: filled ? "1px solid rgba(255,255,255,0.16)" : "1px solid var(--border-soft)",
      }}>{value}</strong>
      <button type="button" aria-label="Добавить одну" onClick={inc} disabled={value >= max}
        style={{ ...btn, opacity: value >= max ? 0.45 : 1 }}>+</button>
    </div>
  );
}
