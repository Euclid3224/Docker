Segmented −/value/+ stepper for changing quantities.

```jsx
const [n, setN] = React.useState(1);
<QuantityControl value={n} onChange={setN} />          {/* caramel, in product card */}
<QuantityControl value={n} onChange={setN} variant="soft" />  {/* white, in cart line */}
```

`filled` is the prominent caramel pill (replaces "В корзину" once an item is added). `soft` is the compact white stepper for cart rows. Buttons disable at `min`/`max`.
