Pill-shaped call-to-action — use for the main action on a screen (Сделать заказ, В корзину, Заказать).

```jsx
<Button href="menu.html">Сделать заказ</Button>
<Button variant="light" size="sm">Весь ассортимент</Button>
<Button variant="ghost">Назад</Button>
<Button fullWidth disabled>Нет в наличии</Button>
```

Variants: `primary` (caramel gradient, default), `light` (cream), `ghost` (outline). Sizes: `sm` / `md` / `lg`. Pass `href` to render an `<a>`. `icon` / `iconRight` accept any node. Hover lifts and brightens; disabled desaturates.
