import * as React from "react";

export interface IconButtonProps {
  /** Icon node — an <img> or inline SVG. */
  children: React.ReactNode;
  /** @default "soft" */
  variant?: "soft" | "outline" | "ghost";
  /** Diameter in px. @default 42 */
  size?: number;
  /** Accessible label (required — control is icon-only). */
  label: string;
  onClick?: (e: React.MouseEvent) => void;
  type?: "button" | "submit" | "reset";
  style?: React.CSSProperties;
}

/** Round, icon-only control for header/drawer actions (search, cart, close). */
export function IconButton(props: IconButtonProps): JSX.Element;
