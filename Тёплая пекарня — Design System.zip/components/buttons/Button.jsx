import React from "react";

/**
 * Button — primary call-to-action for Тёплая пекарня.
 * Pill-shaped, caramel gradient by default. Renders an <a> when `href` is set.
 */
export function Button({
  children,
  variant = "primary",
  size = "md",
  href,
  icon,
  iconRight,
  fullWidth = false,
  disabled = false,
  type = "button",
  onClick,
  style,
  ...rest
}) {
  const palette = {
    primary: {
      background: "linear-gradient(135deg, var(--caramel), var(--caramel-deep))",
      color: "var(--text-on-caramel)",
      boxShadow: "var(--shadow-button)",
      border: "1px solid transparent",
    },
    light: {
      background: "linear-gradient(135deg, var(--cream), var(--white))",
      color: "var(--cocoa)",
      boxShadow: "var(--shadow-sm)",
      border: "1px solid var(--border-soft)",
    },
    ghost: {
      background: "transparent",
      color: "var(--caramel)",
      boxShadow: "none",
      border: "1px solid var(--border-strong)",
    },
  }[variant];

  const sizing = {
    sm: { minHeight: 40, padding: "9px 18px", fontSize: "var(--text-sm)" },
    md: { minHeight: 48, padding: "13px 26px", fontSize: "var(--text-base)" },
    lg: { minHeight: 56, padding: "16px 34px", fontSize: "var(--text-lead)" },
  }[size];

  const styles = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "10px",
    width: fullWidth ? "100%" : undefined,
    borderRadius: "var(--radius-pill)",
    fontFamily: "var(--font-body)",
    fontWeight: "var(--fw-black)",
    lineHeight: 1,
    cursor: disabled ? "not-allowed" : "pointer",
    textDecoration: "none",
    transition: "transform var(--dur) var(--ease), filter var(--dur) var(--ease), box-shadow var(--dur) var(--ease)",
    opacity: disabled ? 0.55 : 1,
    filter: disabled ? "grayscale(0.6)" : undefined,
    ...palette,
    ...sizing,
    ...style,
  };

  const onEnter = (e) => {
    if (disabled) return;
    e.currentTarget.style.transform = "var(--lift)";
    e.currentTarget.style.filter = "saturate(1.08) brightness(1.02)";
  };
  const onLeave = (e) => {
    if (disabled) return;
    e.currentTarget.style.transform = "";
    e.currentTarget.style.filter = "";
  };

  const content = (
    <>
      {icon ? <span aria-hidden="true" style={{ display: "inline-flex" }}>{icon}</span> : null}
      <span>{children}</span>
      {iconRight ? <span aria-hidden="true" style={{ display: "inline-flex" }}>{iconRight}</span> : null}
    </>
  );

  if (href && !disabled) {
    return (
      <a href={href} style={styles} onMouseEnter={onEnter} onMouseLeave={onLeave} {...rest}>
        {content}
      </a>
    );
  }

  return (
    <button
      type={type}
      disabled={disabled}
      onClick={onClick}
      style={styles}
      onMouseEnter={onEnter}
      onMouseLeave={onLeave}
      {...rest}
    >
      {content}
    </button>
  );
}
