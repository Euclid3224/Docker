---
name: teplaya-pekarnya-design
description: Use this skill to generate well-branded interfaces and assets for «Тёплая пекарня» (Warm Bakery), either for production or throwaway prototypes/mocks. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping a warm, artisan bakery brand in Russian.
user-invocable: true
---

Read the `readme.md` file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and
create static HTML files for the user to view. If working on production code, you can copy
assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or
design, ask a few questions, and act as an expert designer who outputs HTML artifacts _or_
production code, depending on the need.

## Quick orientation
- **Brand:** «Тёплая пекарня» — neighbourhood artisan bakery. Russian-language, warm, calm,
  hospitable. Tagline: «Свежая выпечка каждый день».
- **Type:** Cormorant Garamond (display / wordmark, often italic) + Nunito Sans (all body, UI,
  prices, buttons). Body at ~17px for readable Cyrillic.
- **Color:** cream/porcelain surfaces; brown ramp gold→caramel→cocoa→coffee; **caramel
  `#b87538`** is the primary action; olive `leaf` for prices/in-stock only. No blue/purple.
- **Shape:** pill buttons/tabs/badges, 8–12px cards, warm brown shadows, soft hover lift,
  full-bleed hero photos with a left dark protection gradient.

## Files
- `styles.css` — link this one file; it imports all tokens + fonts.
- `tokens/` — colors, typography, spacing/radii/shadows (CSS custom properties).
- `guidelines/` — foundation specimen cards.
- `components/` — React primitives (Button, IconButton, QuantityControl, Input, Badge, Price,
  CategoryTab, ProductCard, Wordmark). Each has a `.prompt.md` with usage.
- `ui_kits/website/` — full interactive recreation of the bakery site.
- `assets/` — fonts, brand SVG icons, photography.

## Using components in an HTML artifact
Load the compiled bundle, then read the namespace:
```html
<link rel="stylesheet" href="styles.css">
<script src="_ds_bundle.js"></script>
<script type="text/babel">
  const { Button, ProductCard } = window.DesignSystem_0db2f9;
</script>
```
(React UMD + Babel must be loaded first — see any card in `components/` for the exact tags.)

## Rules
- Keep copy in Russian, sentence case, «ёлочки» quotes, the letter ё explicit. Eyebrows are the
  only uppercase. No emoji.
- Reuse the brand's own SVG icons; do not redraw or substitute emoji.
- Use caramel for the single primary action per screen; olive only for price/stock.
- Pair Cormorant (display) + Nunito Sans (body) — never set long copy in the serif.
