// App — orchestrates view switching + cart state.
function App() {
  const [view, setView] = React.useState("home");
  const [cart, setCart] = React.useState({});
  const [cartOpen, setCartOpen] = React.useState(false);

  const addToCart = (id) => setCart((c) => ({ ...c, [id]: (c[id] || 0) + 1 }));
  const setQty = (id, n) => setCart((c) => {
    const next = { ...c };
    if (n <= 0) delete next[id]; else next[id] = n;
    return next;
  });
  const cartCount = Object.values(cart).reduce((s, q) => s + q, 0);

  const navigate = (id) => {
    if (id === "gallery" || id === "contacts") {
      setView("home");
      requestAnimationFrame(() => {
        const el = document.querySelector(id === "gallery" ? ".tp-gallery" : ".tp-contacts");
        if (el) window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - 90, behavior: "smooth" });
      });
    } else {
      setView(id);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  return (
    <React.Fragment>
      <window.Header
        view={view}
        onNavigate={navigate}
        cartCount={cartCount}
        onOpenCart={() => setCartOpen(true)}
      />
      {view === "menu"
        ? <window.MenuView cart={cart} onAdd={addToCart} onSetQty={setQty} />
        : <window.HomeView onNavigate={navigate} />}

      <footer className="tp-footer">
        <strong>Тёплая пекарня</strong>
        <p>© 2026. Свежая выпечка каждый день.</p>
      </footer>

      <window.CartDrawer open={cartOpen} cart={cart} onClose={() => setCartOpen(false)} onSetQty={setQty} />
    </React.Fragment>
  );
}
ReactDOM.createRoot(document.getElementById("root")).render(<App />);
