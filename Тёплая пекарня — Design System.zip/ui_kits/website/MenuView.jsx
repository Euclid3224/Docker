// MenuView — sticky category rail + product grid (uses ProductCard).
function MenuView({ cart, onAdd, onSetQty }) {
  const { ProductCard } = window.DesignSystem_0db2f9;
  const products = window.BAKERY_PRODUCTS;
  const categories = window.BAKERY_CATEGORIES;
  const [active, setActive] = React.useState("all");

  const shown = active === "all" ? products : products.filter((p) => p.category === active);
  const title = active === "all" ? "Весь ассортимент" : categories.find((c) => c.id === active).label;

  return (
    <main className="tp-menu">
      {/* Category cards rail */}
      <nav className="tp-cat-rail" aria-label="Категории меню">
        {categories.map((c) => (
          <button
            key={c.id}
            type="button"
            className={"tp-cat-card" + (active === c.id ? " is-active" : "")}
            onClick={() => setActive(active === c.id ? "all" : c.id)}
          >
            <img src={c.icon} alt="" width="52" height="52" />
            <span>{c.label}</span>
          </button>
        ))}
      </nav>

      <section className="tp-catalog">
        <div className="tp-catalog-head">
          <div>
            <p className="tp-eyebrow">Сегодня на витрине</p>
            <h1 className="tp-h2" style={{ marginTop: 4 }}>{title}</h1>
          </div>
        </div>

        <div className="tp-product-grid">
          {shown.map((p) => (
            <ProductCard
              key={p.id}
              name={p.name}
              description={p.description}
              price={p.price}
              image={p.image}
              stock={p.stock}
              compact
              quantity={cart[p.id] || 0}
              onAdd={() => onAdd(p.id)}
              onChange={(n) => onSetQty(p.id, n)}
            />
          ))}
        </div>
      </section>
    </main>
  );
}
window.MenuView = MenuView;
