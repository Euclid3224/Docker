// CartDrawer — slide-in cart with line items, total and a pickup form.
function CartDrawer({ open, cart, onClose, onSetQty }) {
  const { Button, IconButton, QuantityControl, Price, Input } = window.DesignSystem_0db2f9;
  const products = window.BAKERY_PRODUCTS;
  const [checkout, setCheckout] = React.useState(false);

  const lines = Object.entries(cart)
    .filter(([, q]) => q > 0)
    .map(([id, q]) => ({ p: products.find((x) => x.id === id), q }))
    .filter((l) => l.p);
  const total = lines.reduce((s, l) => s + l.p.price * l.q, 0);

  React.useEffect(() => { if (!open) setCheckout(false); }, [open]);

  return (
    <React.Fragment>
      <div className={"tp-backdrop" + (open ? " is-open" : "")} onClick={onClose}></div>
      <aside className={"tp-drawer" + (open ? " is-open" : "")} aria-label="Корзина" aria-hidden={!open}>
        <div className="tp-drawer-head">
          <div>
            <p className="tp-eyebrow">Ваш заказ</p>
            <h2 className="tp-h2" style={{ fontSize: "1.9rem" }}>Корзина</h2>
          </div>
          <IconButton label="Закрыть корзину" onClick={onClose}>×</IconButton>
        </div>

        {lines.length === 0 ? (
          <p className="tp-empty">Корзина пока пуста.</p>
        ) : (
          <div className="tp-cart-items">
            {lines.map(({ p, q }) => (
              <div className="tp-cart-line" key={p.id}>
                <img src={p.image} alt="" />
                <div className="tp-cart-info">
                  <strong>{p.name}</strong>
                  <span>{p.price} ₽</span>
                </div>
                <div style={{ width: 96 }}>
                  <QuantityControl value={q} max={p.stock} variant="soft" onChange={(n) => onSetQty(p.id, n)} />
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="tp-drawer-foot">
          <div className="tp-cart-total">
            <span>Итого</span>
            <Price value={total} variant="plain" style={{ fontSize: "1.4rem" }} />
          </div>

          {!checkout ? (
            <Button fullWidth disabled={lines.length === 0} onClick={() => setCheckout(true)}>
              Заказать
            </Button>
          ) : (
            <form className="tp-order-form" onSubmit={(e) => e.preventDefault()}>
              <p className="tp-pickup-note">Оплата при получении в пекарне — наличными или картой.</p>
              <Input label="Ваше имя" name="name" required placeholder="Как к вам обращаться" />
              <Input label="Телефон" name="phone" type="tel" required placeholder="+7 900 000-00-00" />
              <Input label="Когда забрать" name="pickup" placeholder="Например, сегодня в 18:30" />
              <div className="tp-form-actions">
                <Button variant="ghost" size="sm" onClick={() => setCheckout(false)}>Назад</Button>
                <Button type="submit" size="sm">Подтвердить заказ</Button>
              </div>
            </form>
          )}
        </div>
      </aside>
    </React.Fragment>
  );
}
window.CartDrawer = CartDrawer;
