// HomeView — hero, trust strip, about, gallery, reviews, contacts.
function HomeView({ onNavigate }) {
  const { Button } = window.DesignSystem_0db2f9;

  const trust = [
    { t: "Самовывоз", s: "готовим к вашему времени" },
    { t: "Оплата при получении", s: "наличными или картой" },
    { t: "08:00–20:00", s: "каждый день" },
  ];
  const gallery = [
    "../../assets/images/atmosphere-1.jpg",
    "../../assets/images/atmosphere-2.jpg",
    "../../assets/images/atmosphere-3.jpg",
    "../../assets/images/atmosphere-4.webp",
  ];
  const reviews = [
    { q: "Постоянно покупаем здесь выпечку и остаёмся в восторге. Качество и разнообразие великолепные, персонал внимательный. Спасибо за вкусную выпечку!", n: "Ирина" },
    { q: "Всегда свежая, мягкая, воздушная выпечка, очень вкусные булочки. Цены радуют, а разнообразие впечатляет.", n: "Михаил" },
    { q: "Хорошая пекарня! Отличный ассортимент и превосходное качество. Попробуешь раз — вернёшься снова.", n: "Дмитрий" },
  ];

  return (
    <main>
      {/* Hero */}
      <section className="tp-hero">
        <div className="tp-hero-content">
          <p className="tp-eyebrow tp-eyebrow--sand">Пекарня рядом с домом</p>
          <h1 className="tp-h1">Хлеб, который ждут</h1>
          <p className="tp-hero-text">Печём небольшими партиями, чтобы хлеб хрустел, выпечка оставалась нежной, а кофе согревал.</p>
          <Button size="lg" onClick={() => onNavigate("menu")}>Сделать заказ</Button>
        </div>
      </section>

      {/* Trust strip */}
      <section className="tp-trust">
        {trust.map((it) => (
          <div className="tp-trust-item" key={it.t}>
            <span className="tp-trust-dot" aria-hidden="true"></span>
            <span className="tp-trust-copy"><strong>{it.t}</strong><span>{it.s}</span></span>
          </div>
        ))}
      </section>

      {/* About */}
      <section className="tp-section tp-about">
        <div className="tp-about-text">
          <p className="tp-eyebrow">О нас</p>
          <h2 className="tp-h2">Печём с заботой и простыми ингредиентами</h2>
          <p className="tp-body">Готовим хлеб, десерты и напитки небольшими партиями, чтобы каждый гость получал свежий вкус. В основе работы — натуральные продукты, спокойная атмосфера и любовь к хорошей выпечке.</p>
        </div>
        <div className="tp-about-card">
          <strong>08:00</strong>
          <span>первая партия хлеба уже на витрине</span>
        </div>
      </section>

      {/* Gallery */}
      <section className="tp-section tp-section--band">
        <div className="tp-section-head">
          <p className="tp-eyebrow">Галерея</p>
          <h2 className="tp-h2">Атмосфера пекарни</h2>
        </div>
        <div className="tp-gallery">
          {gallery.map((src, i) => <img key={i} src={src} alt="" loading="lazy" />)}
        </div>
      </section>

      {/* Reviews */}
      <section className="tp-section">
        <div className="tp-section-head">
          <p className="tp-eyebrow">Отзывы</p>
          <h2 className="tp-h2">Что говорят гости</h2>
        </div>
        <div className="tp-reviews">
          {reviews.map((r) => (
            <blockquote className="tp-review" key={r.n}>
              <p>“{r.q}”</p>
              <cite>{r.n}</cite>
            </blockquote>
          ))}
        </div>
      </section>

      {/* Contacts */}
      <section className="tp-section tp-section--band tp-contacts">
        <div>
          <p className="tp-eyebrow">Контакты</p>
          <h2 className="tp-h2">Заглядывайте за свежей выпечкой</h2>
        </div>
        <div className="tp-contact-list">
          <p><strong>Адрес:</strong> Ростовская обл., сл. Родионово-Несветайская, ул. Бабичева, 51</p>
          <p><strong>Телефон:</strong> +7 (929) 816-70-09</p>
          <p><strong>Часы работы:</strong> ежедневно, 08:00–20:00</p>
        </div>
      </section>
    </main>
  );
}
window.HomeView = HomeView;
