# UI Kit — Сайт «Тёплая пекарня»

High-fidelity, clickable recreation of the bakery's public website, rebuilt from the
original codebase (`app/index.html`, `app/menu.html`, `app/style.css`, `app/catalog.js`).

## Files
- `index.html` — entry point. Loads React UMD + Babel + the compiled `_ds_bundle.js`, then the screens below. Manages view + cart state.
- `app.jsx` — orchestrator: view switching (главная / меню), cart state, scroll-to-section.
- `Header.jsx` — sticky bar: wordmark, nav, search + cart with live count.
- `HomeView.jsx` — hero, trust strip, «О нас», галерея, отзывы, контакты.
- `MenuView.jsx` — category rail + tabs + product grid (`ProductCard`).
- `CartDrawer.jsx` — slide-in cart with line items, total and the pickup-order form.
- `products.js` — demo catalog + categories (`window.BAKERY_PRODUCTS`, `window.BAKERY_CATEGORIES`).

## Interactions to try
1. Land on the home page → click **Сделать заказ** (or **Меню** in the nav) to open the catalog.
2. Filter by **Хлеб / Выпечка / Десерты / Напитки** via the icon cards or the pill tabs.
3. Press **В корзину** on a product — the button flips to a caramel −/+ stepper.
4. Open the cart (top-right) → **Заказать** reveals the pickup form (имя, телефон, время).
5. «Сосиска в тесте» is intentionally out of stock — shows the disabled state.

## Notes
- Composes the shared primitives: `Button`, `IconButton`, `QuantityControl`, `ProductCard`,
  `Badge`, `Price`, `CategoryTab`, `Input`, `Wordmark`. Do not re-implement these here.
- Product photos are reused from the brand asset set; the live shop stores per-product images.
- Cart state is in-memory (demo only) — no persistence or backend.
