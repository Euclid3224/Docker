// Тёплая пекарня — demo catalog data for the UI kit.
// Photos are reused from the brand asset set; prices/stock mirror the real shop.
window.BAKERY_PRODUCTS = [
  { id: "bread-1",  category: "bread",    name: "Хлеб пшеничный",   price: 55, stock: 8,  image: "../../assets/images/atmosphere-4.webp", description: "Хрустящая корочка и мягкий мякиш — печём первой партией к 08:00." },
  { id: "bread-2",  category: "bread",    name: "Деревенский на закваске", price: 95, stock: 4, image: "../../assets/images/hero-bakery.webp", description: "Долгое брожение, плотный мякиш и насыщенный вкус зерна." },
  { id: "pastry-1", category: "pastry",   name: "Хачапури с сыром", price: 75, stock: 5,  image: "../../assets/images/bakery-1.jfif", description: "Сочная сырная начинка в нежном тесте — берут ещё тёплым." },
  { id: "pastry-2", category: "pastry",   name: "Самса с курицей",  price: 85, stock: 11, image: "../../assets/images/bakery-2.jfif", description: "Плотное слоёное тесто, ароматная курица и немного специй." },
  { id: "pastry-3", category: "pastry",   name: "Сосиска в тесте",  price: 60, stock: 0,  image: "../../assets/images/bakery-1.jfif", description: "Нежное тесто и сочная сосиска для быстрого перекуса." },
  { id: "dessert-1",category: "desserts", name: "Корзиночка с кремом", price: 90, stock: 7, image: "../../assets/images/bakery-2.jfif", description: "Песочная корзиночка с воздушным заварным кремом." },
  { id: "drink-1",  category: "drinks",   name: "Капучино",         price: 140, stock: 30, image: "../../assets/images/atmosphere-4.webp", description: "На зерне свежей обжарки — согревает в любую погоду." },
];

window.BAKERY_CATEGORIES = [
  { id: "bread",    label: "Хлеб",    icon: "../../assets/icons/nav-bread.svg" },
  { id: "pastry",   label: "Выпечка", icon: "../../assets/icons/nav-pastry.svg" },
  { id: "desserts", label: "Десерты", icon: "../../assets/icons/nav-desserts.svg" },
  { id: "drinks",   label: "Напитки", icon: "../../assets/icons/nav-drinks.svg" },
];
