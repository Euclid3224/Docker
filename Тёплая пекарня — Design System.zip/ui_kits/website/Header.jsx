// Header — sticky top bar: wordmark, nav, search + cart actions.
function Header({ view, onNavigate, cartCount, onOpenCart }) {
  const { Wordmark, IconButton } = window.DesignSystem_0db2f9;
  const link = (id, label) => (
    <button
      type="button"
      onClick={() => onNavigate(id)}
      className={"tp-nav-link" + (view === id ? " is-active" : "")}
    >
      {label}
    </button>
  );

  return (
    <header className="tp-header">
      <div onClick={() => onNavigate("home")} style={{ cursor: "pointer" }}>
        <Wordmark layout="stacked" size={0.62} />
      </div>

      <nav className="tp-nav" aria-label="Основная навигация">
        {link("home", "О нас")}
        {link("menu", "Меню")}
        {link("gallery", "Галерея")}
        {link("contacts", "Контакты")}
      </nav>

      <div className="tp-header-actions">
        {view === "menu" ? (
          <React.Fragment>
            <IconButton variant="ghost" label="Поиск">
              <img src="../../assets/icons/icon-search.svg" alt="" width="22" height="22" />
            </IconButton>
            <button type="button" className="tp-cart-btn" onClick={onOpenCart} aria-label={`Корзина, товаров: ${cartCount}`}>
              <img src="../../assets/icons/nav-cart.svg" alt="" width="30" height="30" />
              {cartCount > 0 ? <span className="tp-cart-count">{cartCount}</span> : null}
            </button>
          </React.Fragment>
        ) : null}
      </div>
    </header>
  );
}
window.Header = Header;
