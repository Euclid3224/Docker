/* @ds-bundle: {"format":3,"namespace":"DesignSystem_0db2f9","components":[{"name":"Wordmark","sourcePath":"components/brand/Wordmark.jsx"},{"name":"Button","sourcePath":"components/buttons/Button.jsx"},{"name":"IconButton","sourcePath":"components/buttons/IconButton.jsx"},{"name":"QuantityControl","sourcePath":"components/buttons/QuantityControl.jsx"},{"name":"Badge","sourcePath":"components/commerce/Badge.jsx"},{"name":"CategoryTab","sourcePath":"components/commerce/CategoryTab.jsx"},{"name":"Price","sourcePath":"components/commerce/Price.jsx"},{"name":"ProductCard","sourcePath":"components/commerce/ProductCard.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"}],"sourceHashes":{"components/brand/Wordmark.jsx":"0b995e177901","components/buttons/Button.jsx":"6e6d65e21117","components/buttons/IconButton.jsx":"c1014ba983b2","components/buttons/QuantityControl.jsx":"3ca4a4bfb8b3","components/commerce/Badge.jsx":"06feacd94391","components/commerce/CategoryTab.jsx":"e9e9e8d8b060","components/commerce/Price.jsx":"957980b6886b","components/commerce/ProductCard.jsx":"bf8923d3fde9","components/forms/Input.jsx":"6e5c142f671b","ui_kits/website/CartDrawer.jsx":"a376032deaa1","ui_kits/website/Header.jsx":"eeda58a40b16","ui_kits/website/HomeView.jsx":"27cb755e4bb8","ui_kits/website/MenuView.jsx":"c1853a1bc386","ui_kits/website/app.jsx":"25578a193207","ui_kits/website/products.js":"1580749ed3da"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.DesignSystem_0db2f9 = window.DesignSystem_0db2f9 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/brand/Wordmark.jsx
try { (() => {
/**
 * Wordmark — "Тёплая пекарня" logotype in Cormorant Garamond italic.
 * Variants:
 *   • "type"   — bare logotype: `stacked` (two lines, header) or `inline` (footer)
 *   • "emblem" — centred badge lockup with gold hairline flourishes + tagline
 */
function Wordmark({
  tone = "dark",
  variant = "type",
  layout = "stacked",
  size = 1,
  tagline = "Свежая выпечка каждый день",
  href,
  style
}) {
  const color = tone === "light" ? "var(--cream)" : "var(--cocoa)";
  const flourish = tone === "light" ? "var(--sand)" : "var(--gold)";
  let inner;
  if (variant === "emblem") {
    const rule = /*#__PURE__*/React.createElement("span", {
      "aria-hidden": "true",
      style: {
        flex: 1,
        height: 1,
        minWidth: `${22 * size}px`,
        background: `linear-gradient(90deg, transparent, ${flourish})`
      }
    });
    inner = /*#__PURE__*/React.createElement("span", {
      style: {
        display: "grid",
        justifyItems: "center",
        gap: `${0.5 * size}em`,
        fontFamily: "var(--font-display)",
        color,
        textAlign: "center"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: `${0.55 * size}em`,
        width: "100%"
      }
    }, rule, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "var(--font-body)",
        fontWeight: 800,
        fontSize: `${0.62 * size}rem`,
        letterSpacing: "0.22em",
        textTransform: "uppercase",
        color: flourish,
        whiteSpace: "nowrap"
      }
    }, "\u041F\u0435\u043A\u0430\u0440\u043D\u044F"), /*#__PURE__*/React.createElement("span", {
      style: {
        transform: "scaleX(-1)",
        display: "flex",
        flex: 1
      }
    }, rule)), /*#__PURE__*/React.createElement("span", {
      style: {
        display: "grid",
        lineHeight: 0.9,
        fontStyle: "italic"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: `${2.0 * size}rem`,
        fontWeight: 500
      }
    }, "\u0422\u0451\u043F\u043B\u0430\u044F"), /*#__PURE__*/React.createElement("strong", {
      style: {
        fontSize: `${2.7 * size}rem`,
        fontWeight: 700
      }
    }, "\u043F\u0435\u043A\u0430\u0440\u043D\u044F")), tagline ? /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "var(--font-body)",
        fontWeight: 700,
        fontSize: `${0.6 * size}rem`,
        letterSpacing: "0.14em",
        textTransform: "uppercase",
        color: tone === "light" ? "var(--text-on-dark)" : "var(--text-muted)"
      }
    }, tagline) : null);
  } else {
    const stacked = layout === "stacked";
    inner = /*#__PURE__*/React.createElement("span", {
      style: {
        display: stacked ? "grid" : "inline-flex",
        alignItems: "baseline",
        gap: stacked ? 0 : "0.34em",
        lineHeight: stacked ? 0.92 : 1,
        fontFamily: "var(--font-display)",
        fontStyle: "italic",
        color
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: `${1.9 * size}rem`,
        fontWeight: 500
      }
    }, "\u0422\u0451\u043F\u043B\u0430\u044F"), /*#__PURE__*/React.createElement("strong", {
      style: {
        fontSize: `${(stacked ? 2.5 : 1.9) * size}rem`,
        fontWeight: 700
      }
    }, "\u043F\u0435\u043A\u0430\u0440\u043D\u044F"));
  }
  if (href) {
    return /*#__PURE__*/React.createElement("a", {
      href: href,
      "aria-label": "\u0422\u0451\u043F\u043B\u0430\u044F \u043F\u0435\u043A\u0430\u0440\u043D\u044F \u2014 \u043D\u0430 \u0433\u043B\u0430\u0432\u043D\u0443\u044E",
      style: {
        textDecoration: "none",
        display: "inline-block",
        ...style
      }
    }, inner);
  }
  return /*#__PURE__*/React.createElement("span", {
    style: style
  }, inner);
}
Object.assign(__ds_scope, { Wordmark });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Wordmark.jsx", error: String((e && e.message) || e) }); }

// components/buttons/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Button — primary call-to-action for Тёплая пекарня.
 * Pill-shaped, caramel gradient by default. Renders an <a> when `href` is set.
 */
function Button({
  children,
  variant = "primary",
  size = "md",
  href,
  icon,
  iconRight,
  fullWidth = false,
  disabled = false,
  type = "button",
  onClick,
  style,
  ...rest
}) {
  const palette = {
    primary: {
      background: "linear-gradient(135deg, var(--caramel), var(--caramel-deep))",
      color: "var(--text-on-caramel)",
      boxShadow: "var(--shadow-button)",
      border: "1px solid transparent"
    },
    light: {
      background: "linear-gradient(135deg, var(--cream), var(--white))",
      color: "var(--cocoa)",
      boxShadow: "var(--shadow-sm)",
      border: "1px solid var(--border-soft)"
    },
    ghost: {
      background: "transparent",
      color: "var(--caramel)",
      boxShadow: "none",
      border: "1px solid var(--border-strong)"
    }
  }[variant];
  const sizing = {
    sm: {
      minHeight: 40,
      padding: "9px 18px",
      fontSize: "var(--text-sm)"
    },
    md: {
      minHeight: 48,
      padding: "13px 26px",
      fontSize: "var(--text-base)"
    },
    lg: {
      minHeight: 56,
      padding: "16px 34px",
      fontSize: "var(--text-lead)"
    }
  }[size];
  const styles = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "10px",
    width: fullWidth ? "100%" : undefined,
    borderRadius: "var(--radius-pill)",
    fontFamily: "var(--font-body)",
    fontWeight: "var(--fw-black)",
    lineHeight: 1,
    cursor: disabled ? "not-allowed" : "pointer",
    textDecoration: "none",
    transition: "transform var(--dur) var(--ease), filter var(--dur) var(--ease), box-shadow var(--dur) var(--ease)",
    opacity: disabled ? 0.55 : 1,
    filter: disabled ? "grayscale(0.6)" : undefined,
    ...palette,
    ...sizing,
    ...style
  };
  const onEnter = e => {
    if (disabled) return;
    e.currentTarget.style.transform = "var(--lift)";
    e.currentTarget.style.filter = "saturate(1.08) brightness(1.02)";
  };
  const onLeave = e => {
    if (disabled) return;
    e.currentTarget.style.transform = "";
    e.currentTarget.style.filter = "";
  };
  const content = /*#__PURE__*/React.createElement(React.Fragment, null, icon ? /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      display: "inline-flex"
    }
  }, icon) : null, /*#__PURE__*/React.createElement("span", null, children), iconRight ? /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      display: "inline-flex"
    }
  }, iconRight) : null);
  if (href && !disabled) {
    return /*#__PURE__*/React.createElement("a", _extends({
      href: href,
      style: styles,
      onMouseEnter: onEnter,
      onMouseLeave: onLeave
    }, rest), content);
  }
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled,
    onClick: onClick,
    style: styles,
    onMouseEnter: onEnter,
    onMouseLeave: onLeave
  }, rest), content);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/buttons/Button.jsx", error: String((e && e.message) || e) }); }

// components/buttons/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconButton — round, icon-only control (close, search, menu).
 * Pass an <img> or inline SVG as children.
 */
function IconButton({
  children,
  variant = "soft",
  size = 42,
  label,
  onClick,
  type = "button",
  style,
  ...rest
}) {
  const palette = {
    soft: {
      background: "var(--cream)",
      color: "var(--cocoa)",
      border: "1px solid transparent"
    },
    outline: {
      background: "var(--white)",
      color: "var(--cocoa)",
      border: "1px solid var(--border-soft)"
    },
    ghost: {
      background: "transparent",
      color: "var(--cocoa)",
      border: "1px solid transparent"
    }
  }[variant];
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    "aria-label": label,
    onClick: onClick,
    style: {
      display: "grid",
      placeItems: "center",
      width: size,
      height: size,
      borderRadius: "var(--radius-circle)",
      cursor: "pointer",
      fontFamily: "var(--font-body)",
      fontSize: "1.4rem",
      lineHeight: 1,
      transition: "background var(--dur-fast) var(--ease), transform var(--dur-fast) var(--ease)",
      ...palette,
      ...style
    },
    onMouseEnter: e => {
      e.currentTarget.style.background = "var(--milk)";
    },
    onMouseLeave: e => {
      e.currentTarget.style.background = palette.background;
    }
  }, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/buttons/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/buttons/QuantityControl.jsx
try { (() => {
/**
 * QuantityControl — segmented −/value/+ stepper.
 * Caramel "add" style when filled; used inside product cards and the cart.
 */
function QuantityControl({
  value = 1,
  min = 0,
  max = 99,
  onChange,
  variant = "filled",
  style
}) {
  const filled = variant === "filled";
  const dec = () => onChange && onChange(Math.max(min, value - 1));
  const inc = () => onChange && onChange(Math.min(max, value + 1));
  const wrap = filled ? {
    background: "linear-gradient(135deg, var(--caramel), var(--caramel-deep))",
    color: "var(--white)",
    boxShadow: "var(--shadow-button)",
    minHeight: 48,
    gridTemplateColumns: "52px minmax(0,1fr) 52px"
  } : {
    background: "var(--white)",
    color: "var(--cocoa)",
    border: "1px solid var(--border-soft)",
    minHeight: 38,
    gridTemplateColumns: "38px minmax(0,1fr) 38px"
  };
  const btn = {
    border: 0,
    background: filled ? "rgba(255,255,255,0.08)" : "var(--cream)",
    color: "inherit",
    font: "inherit",
    fontSize: "1.3rem",
    fontWeight: "var(--fw-black)",
    cursor: "pointer",
    display: "grid",
    placeItems: "center"
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      alignItems: "center",
      overflow: "hidden",
      borderRadius: "var(--radius-pill)",
      fontFamily: "var(--font-body)",
      ...wrap,
      ...style
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "\u0423\u0431\u0440\u0430\u0442\u044C \u043E\u0434\u043D\u0443",
    onClick: dec,
    disabled: value <= min,
    style: {
      ...btn,
      opacity: value <= min ? 0.45 : 1
    }
  }, "\u2212"), /*#__PURE__*/React.createElement("strong", {
    style: {
      display: "grid",
      placeItems: "center",
      fontSize: "var(--text-base)",
      borderLeft: filled ? "1px solid rgba(255,255,255,0.16)" : "1px solid var(--border-soft)",
      borderRight: filled ? "1px solid rgba(255,255,255,0.16)" : "1px solid var(--border-soft)"
    }
  }, value), /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u043E\u0434\u043D\u0443",
    onClick: inc,
    disabled: value >= max,
    style: {
      ...btn,
      opacity: value >= max ? 0.45 : 1
    }
  }, "+"));
}
Object.assign(__ds_scope, { QuantityControl });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/buttons/QuantityControl.jsx", error: String((e && e.message) || e) }); }

// components/commerce/Badge.jsx
try { (() => {
/**
 * Badge — small status pill. Stock states use leaf (in stock) / berry (out).
 */
function Badge({
  children,
  tone = "success",
  style
}) {
  const palette = {
    success: {
      background: "rgba(111,127,77,0.13)",
      color: "var(--leaf)"
    },
    danger: {
      background: "rgba(142,58,44,0.10)",
      color: "var(--berry)"
    },
    neutral: {
      background: "var(--milk)",
      color: "var(--cocoa)"
    },
    caramel: {
      background: "rgba(184,117,56,0.14)",
      color: "var(--caramel)"
    }
  }[tone];
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      minHeight: 30,
      padding: "3px 12px",
      borderRadius: "var(--radius-pill)",
      fontFamily: "var(--font-body)",
      fontSize: "var(--text-xs)",
      fontWeight: "var(--fw-black)",
      lineHeight: 1,
      whiteSpace: "nowrap",
      ...palette,
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/commerce/Badge.jsx", error: String((e && e.message) || e) }); }

// components/commerce/CategoryTab.jsx
try { (() => {
/**
 * CategoryTab — pill tab for filtering the menu by category.
 * Active state fills caramel; optional icon node.
 */
function CategoryTab({
  children,
  active = false,
  icon,
  onClick,
  style
}) {
  const base = {
    display: "inline-flex",
    alignItems: "center",
    gap: "8px",
    minHeight: 46,
    padding: "11px 20px",
    borderRadius: "var(--radius-pill)",
    fontFamily: "var(--font-body)",
    fontWeight: "var(--fw-black)",
    fontSize: "var(--text-sm)",
    lineHeight: 1,
    cursor: "pointer",
    transition: "background var(--dur-fast) var(--ease), border-color var(--dur-fast) var(--ease), color var(--dur-fast) var(--ease), transform var(--dur-fast) var(--ease)"
  };
  const state = active ? {
    background: "var(--caramel)",
    color: "var(--white)",
    border: "1px solid var(--border-strong)",
    boxShadow: "var(--shadow-sm)"
  } : {
    background: "var(--white)",
    color: "var(--cocoa)",
    border: "1px solid var(--border-soft)",
    boxShadow: "var(--shadow-sm)"
  };
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-pressed": active,
    onClick: onClick,
    style: {
      ...base,
      ...state,
      ...style
    },
    onMouseEnter: e => {
      if (!active) {
        e.currentTarget.style.background = "var(--milk)";
      }
      e.currentTarget.style.transform = "translateY(-2px)";
    },
    onMouseLeave: e => {
      if (!active) {
        e.currentTarget.style.background = "var(--white)";
      }
      e.currentTarget.style.transform = "";
    }
  }, icon ? /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      display: "inline-flex"
    }
  }, icon) : null, children);
}
Object.assign(__ds_scope, { CategoryTab });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/commerce/CategoryTab.jsx", error: String((e && e.message) || e) }); }

// components/commerce/Price.jsx
try { (() => {
/**
 * Price — formatted rouble price. `pill` (olive chip) or `plain` (caramel text).
 */
function Price({
  value,
  variant = "pill",
  style
}) {
  const formatted = typeof value === "number" ? `${value.toLocaleString("ru-RU")} ₽` : value;
  if (variant === "plain") {
    return /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "var(--font-body)",
        fontWeight: "var(--fw-black)",
        fontSize: "var(--text-base)",
        color: "var(--caramel)",
        whiteSpace: "nowrap",
        ...style
      }
    }, formatted);
  }
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      minHeight: 34,
      minWidth: 70,
      padding: "4px 14px",
      borderRadius: "var(--radius-pill)",
      background: "rgba(111,127,77,0.12)",
      color: "var(--leaf)",
      fontFamily: "var(--font-body)",
      fontWeight: 900,
      fontSize: "var(--text-base)",
      whiteSpace: "nowrap",
      ...style
    }
  }, formatted);
}
Object.assign(__ds_scope, { Price });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/commerce/Price.jsx", error: String((e && e.message) || e) }); }

// components/commerce/ProductCard.jsx
try { (() => {
/**
 * ProductCard — catalog card: image, stock, price, name and an "add to cart"
 * action that flips to a quantity stepper.
 *
 * `compact` (used in the menu grid) drops the description, shrinks the button and
 * lays price + action on one tidy row for a cleaner, more elegant tile.
 */
function ProductCard({
  name,
  description,
  price,
  image,
  stock = 0,
  quantity = 0,
  compact = false,
  onAdd,
  onChange,
  style
}) {
  const soldOut = stock <= 0;
  const [hover, setHover] = React.useState(false);
  const action = soldOut ? /*#__PURE__*/React.createElement(__ds_scope.Button, {
    size: "sm",
    disabled: true,
    style: {
      pointerEvents: "none"
    }
  }, "\u041D\u0435\u0442") : quantity > 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      width: compact ? 104 : "100%"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.QuantityControl, {
    value: quantity,
    max: stock,
    variant: compact ? "soft" : "filled",
    onChange: onChange
  })) : /*#__PURE__*/React.createElement(__ds_scope.Button, {
    size: "sm",
    fullWidth: !compact,
    onClick: onAdd
  }, "\u0412 \u043A\u043E\u0440\u0437\u0438\u043D\u0443");
  return /*#__PURE__*/React.createElement("article", {
    className: "ds-pcard",
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "flex",
      flexDirection: "column",
      minWidth: 0,
      overflow: "hidden",
      borderRadius: "var(--radius-md)",
      background: "var(--surface-raised)",
      border: "1px solid var(--border-soft)",
      boxShadow: hover ? "var(--shadow-hover)" : "var(--shadow)",
      transform: hover ? "var(--lift-card)" : "none",
      transition: "transform var(--dur) var(--ease), box-shadow var(--dur) var(--ease)",
      fontFamily: "var(--font-body)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ds-pcard__media",
    style: {
      position: "relative",
      overflow: "hidden",
      height: compact ? 150 : 200
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: name,
    style: {
      display: "block",
      width: "100%",
      height: "100%",
      objectFit: "cover",
      objectPosition: "center 25%",
      filter: soldOut ? "grayscale(0.5) brightness(0.95)" : "none",
      transform: hover && !soldOut ? "scale(1.05)" : "none",
      transition: "transform var(--dur-slow) var(--ease)"
    }
  }), soldOut ? /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: 10,
      left: 10,
      padding: "3px 11px",
      borderRadius: "var(--radius-pill)",
      background: "rgba(39,24,18,0.78)",
      color: "var(--cream)",
      fontSize: "var(--text-xs)",
      fontWeight: "var(--fw-black)",
      lineHeight: 1
    }
  }, "\u041D\u0435\u0442 \u0432 \u043D\u0430\u043B\u0438\u0447\u0438\u0438") : null), compact ? /*#__PURE__*/React.createElement("div", {
    className: "ds-pcard__body",
    style: {
      display: "flex",
      flexDirection: "column",
      flex: 1,
      padding: "13px 14px 15px",
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("h3", {
    className: "ds-pcard__title",
    style: {
      margin: 0,
      fontFamily: "var(--font-display)",
      fontWeight: 600,
      fontSize: "1.32rem",
      lineHeight: 1.12,
      color: "var(--text-heading)",
      textWrap: "pretty"
    }
  }, name), !soldOut ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-xs)",
      fontWeight: "var(--fw-bold)",
      color: "var(--leaf)"
    }
  }, "\u0412 \u043D\u0430\u043B\u0438\u0447\u0438\u0438 \xB7 ", stock, " \u0448\u0442.") : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 10,
      marginTop: "auto",
      paddingTop: 10
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Price, {
    value: price,
    variant: "plain",
    style: {
      fontSize: "1.18rem"
    }
  }), action)) : /*#__PURE__*/React.createElement("div", {
    className: "ds-pcard__body",
    style: {
      display: "flex",
      flexDirection: "column",
      flex: 1,
      padding: "20px 22px 22px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ds-pcard__meta",
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 8,
      flexWrap: "wrap",
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: soldOut ? "danger" : "success"
  }, soldOut ? "Нет в наличии" : `В наличии: ${stock} шт.`), /*#__PURE__*/React.createElement(__ds_scope.Price, {
    value: price,
    variant: "plain"
  })), /*#__PURE__*/React.createElement("h3", {
    className: "ds-pcard__title",
    style: {
      margin: "0 0 8px",
      fontFamily: "var(--font-display)",
      fontWeight: 600,
      fontSize: "var(--text-h3)",
      lineHeight: "var(--lh-tight)",
      color: "var(--text-heading)"
    }
  }, name), /*#__PURE__*/React.createElement("p", {
    className: "ds-pcard__desc",
    style: {
      flex: 1,
      margin: "0 0 18px",
      fontSize: "var(--text-sm)",
      lineHeight: "var(--lh-body)",
      color: "var(--text-body)"
    }
  }, description), soldOut ? /*#__PURE__*/React.createElement(__ds_scope.Button, {
    fullWidth: true,
    disabled: true
  }, "\u041D\u0435\u0442 \u0432 \u043D\u0430\u043B\u0438\u0447\u0438\u0438") : quantity > 0 ? /*#__PURE__*/React.createElement(__ds_scope.QuantityControl, {
    value: quantity,
    max: stock,
    onChange: onChange
  }) : /*#__PURE__*/React.createElement(__ds_scope.Button, {
    fullWidth: true,
    onClick: onAdd
  }, "\u0412 \u043A\u043E\u0440\u0437\u0438\u043D\u0443")));
}
Object.assign(__ds_scope, { ProductCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/commerce/ProductCard.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Input — labelled text field used in the pickup-order form.
 * Renders a textarea when `multiline` is set.
 */
function Input({
  label,
  name,
  type = "text",
  placeholder,
  value,
  defaultValue,
  onChange,
  required = false,
  multiline = false,
  rows = 3,
  style,
  ...rest
}) {
  const field = {
    width: "100%",
    boxSizing: "border-box",
    minHeight: multiline ? undefined : 48,
    padding: "13px 16px",
    borderRadius: "var(--radius-sm)",
    border: "1px solid var(--border-soft)",
    background: "var(--white)",
    color: "var(--text-strong)",
    fontFamily: "var(--font-body)",
    fontSize: "var(--text-base)",
    lineHeight: "var(--lh-body)",
    outline: "none",
    transition: "border-color var(--dur-fast) var(--ease), box-shadow var(--dur-fast) var(--ease)",
    resize: multiline ? "vertical" : undefined
  };
  const onFocus = e => {
    e.currentTarget.style.borderColor = "var(--border-strong)";
    e.currentTarget.style.boxShadow = "0 0 0 3px rgba(216,166,77,0.25)";
  };
  const onBlur = e => {
    e.currentTarget.style.borderColor = "var(--border-soft)";
    e.currentTarget.style.boxShadow = "none";
  };
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "grid",
      gap: "7px",
      fontFamily: "var(--font-body)",
      ...style
    }
  }, label ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-sm)",
      fontWeight: "var(--fw-bold)",
      color: "var(--text-heading)"
    }
  }, label, required ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--danger)"
    }
  }, " *") : null) : null, multiline ? /*#__PURE__*/React.createElement("textarea", _extends({
    name: name,
    placeholder: placeholder,
    rows: rows,
    value: value,
    defaultValue: defaultValue,
    onChange: onChange,
    required: required,
    style: field,
    onFocus: onFocus,
    onBlur: onBlur
  }, rest)) : /*#__PURE__*/React.createElement("input", _extends({
    name: name,
    type: type,
    placeholder: placeholder,
    value: value,
    defaultValue: defaultValue,
    onChange: onChange,
    required: required,
    style: field,
    onFocus: onFocus,
    onBlur: onBlur
  }, rest)));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/CartDrawer.jsx
try { (() => {
// CartDrawer — slide-in cart with line items, total and a pickup form.
function CartDrawer({
  open,
  cart,
  onClose,
  onSetQty
}) {
  const {
    Button,
    IconButton,
    QuantityControl,
    Price,
    Input
  } = window.DesignSystem_0db2f9;
  const products = window.BAKERY_PRODUCTS;
  const [checkout, setCheckout] = React.useState(false);
  const lines = Object.entries(cart).filter(([, q]) => q > 0).map(([id, q]) => ({
    p: products.find(x => x.id === id),
    q
  })).filter(l => l.p);
  const total = lines.reduce((s, l) => s + l.p.price * l.q, 0);
  React.useEffect(() => {
    if (!open) setCheckout(false);
  }, [open]);
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "tp-backdrop" + (open ? " is-open" : ""),
    onClick: onClose
  }), /*#__PURE__*/React.createElement("aside", {
    className: "tp-drawer" + (open ? " is-open" : ""),
    "aria-label": "\u041A\u043E\u0440\u0437\u0438\u043D\u0430",
    "aria-hidden": !open
  }, /*#__PURE__*/React.createElement("div", {
    className: "tp-drawer-head"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    className: "tp-eyebrow"
  }, "\u0412\u0430\u0448 \u0437\u0430\u043A\u0430\u0437"), /*#__PURE__*/React.createElement("h2", {
    className: "tp-h2",
    style: {
      fontSize: "1.9rem"
    }
  }, "\u041A\u043E\u0440\u0437\u0438\u043D\u0430")), /*#__PURE__*/React.createElement(IconButton, {
    label: "\u0417\u0430\u043A\u0440\u044B\u0442\u044C \u043A\u043E\u0440\u0437\u0438\u043D\u0443",
    onClick: onClose
  }, "\xD7")), lines.length === 0 ? /*#__PURE__*/React.createElement("p", {
    className: "tp-empty"
  }, "\u041A\u043E\u0440\u0437\u0438\u043D\u0430 \u043F\u043E\u043A\u0430 \u043F\u0443\u0441\u0442\u0430.") : /*#__PURE__*/React.createElement("div", {
    className: "tp-cart-items"
  }, lines.map(({
    p,
    q
  }) => /*#__PURE__*/React.createElement("div", {
    className: "tp-cart-line",
    key: p.id
  }, /*#__PURE__*/React.createElement("img", {
    src: p.image,
    alt: ""
  }), /*#__PURE__*/React.createElement("div", {
    className: "tp-cart-info"
  }, /*#__PURE__*/React.createElement("strong", null, p.name), /*#__PURE__*/React.createElement("span", null, p.price, " \u20BD")), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 96
    }
  }, /*#__PURE__*/React.createElement(QuantityControl, {
    value: q,
    max: p.stock,
    variant: "soft",
    onChange: n => onSetQty(p.id, n)
  }))))), /*#__PURE__*/React.createElement("div", {
    className: "tp-drawer-foot"
  }, /*#__PURE__*/React.createElement("div", {
    className: "tp-cart-total"
  }, /*#__PURE__*/React.createElement("span", null, "\u0418\u0442\u043E\u0433\u043E"), /*#__PURE__*/React.createElement(Price, {
    value: total,
    variant: "plain",
    style: {
      fontSize: "1.4rem"
    }
  })), !checkout ? /*#__PURE__*/React.createElement(Button, {
    fullWidth: true,
    disabled: lines.length === 0,
    onClick: () => setCheckout(true)
  }, "\u0417\u0430\u043A\u0430\u0437\u0430\u0442\u044C") : /*#__PURE__*/React.createElement("form", {
    className: "tp-order-form",
    onSubmit: e => e.preventDefault()
  }, /*#__PURE__*/React.createElement("p", {
    className: "tp-pickup-note"
  }, "\u041E\u043F\u043B\u0430\u0442\u0430 \u043F\u0440\u0438 \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u0438\u0438 \u0432 \u043F\u0435\u043A\u0430\u0440\u043D\u0435 \u2014 \u043D\u0430\u043B\u0438\u0447\u043D\u044B\u043C\u0438 \u0438\u043B\u0438 \u043A\u0430\u0440\u0442\u043E\u0439."), /*#__PURE__*/React.createElement(Input, {
    label: "\u0412\u0430\u0448\u0435 \u0438\u043C\u044F",
    name: "name",
    required: true,
    placeholder: "\u041A\u0430\u043A \u043A \u0432\u0430\u043C \u043E\u0431\u0440\u0430\u0449\u0430\u0442\u044C\u0441\u044F"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "\u0422\u0435\u043B\u0435\u0444\u043E\u043D",
    name: "phone",
    type: "tel",
    required: true,
    placeholder: "+7 900 000-00-00"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "\u041A\u043E\u0433\u0434\u0430 \u0437\u0430\u0431\u0440\u0430\u0442\u044C",
    name: "pickup",
    placeholder: "\u041D\u0430\u043F\u0440\u0438\u043C\u0435\u0440, \u0441\u0435\u0433\u043E\u0434\u043D\u044F \u0432 18:30"
  }), /*#__PURE__*/React.createElement("div", {
    className: "tp-form-actions"
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    onClick: () => setCheckout(false)
  }, "\u041D\u0430\u0437\u0430\u0434"), /*#__PURE__*/React.createElement(Button, {
    type: "submit",
    size: "sm"
  }, "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C \u0437\u0430\u043A\u0430\u0437"))))));
}
window.CartDrawer = CartDrawer;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/CartDrawer.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Header.jsx
try { (() => {
// Header — sticky top bar: wordmark, nav, search + cart actions.
function Header({
  view,
  onNavigate,
  cartCount,
  onOpenCart
}) {
  const {
    Wordmark,
    IconButton
  } = window.DesignSystem_0db2f9;
  const link = (id, label) => /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: () => onNavigate(id),
    className: "tp-nav-link" + (view === id ? " is-active" : "")
  }, label);
  return /*#__PURE__*/React.createElement("header", {
    className: "tp-header"
  }, /*#__PURE__*/React.createElement("div", {
    onClick: () => onNavigate("home"),
    style: {
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement(Wordmark, {
    layout: "stacked",
    size: 0.62
  })), /*#__PURE__*/React.createElement("nav", {
    className: "tp-nav",
    "aria-label": "\u041E\u0441\u043D\u043E\u0432\u043D\u0430\u044F \u043D\u0430\u0432\u0438\u0433\u0430\u0446\u0438\u044F"
  }, link("home", "О нас"), link("menu", "Меню"), link("gallery", "Галерея"), link("contacts", "Контакты")), /*#__PURE__*/React.createElement("div", {
    className: "tp-header-actions"
  }, view === "menu" ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(IconButton, {
    variant: "ghost",
    label: "\u041F\u043E\u0438\u0441\u043A"
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/icons/icon-search.svg",
    alt: "",
    width: "22",
    height: "22"
  })), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "tp-cart-btn",
    onClick: onOpenCart,
    "aria-label": `Корзина, товаров: ${cartCount}`
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/icons/nav-cart.svg",
    alt: "",
    width: "30",
    height: "30"
  }), cartCount > 0 ? /*#__PURE__*/React.createElement("span", {
    className: "tp-cart-count"
  }, cartCount) : null)) : null));
}
window.Header = Header;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Header.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/HomeView.jsx
try { (() => {
// HomeView — hero, trust strip, about, gallery, reviews, contacts.
function HomeView({
  onNavigate
}) {
  const {
    Button
  } = window.DesignSystem_0db2f9;
  const trust = [{
    t: "Самовывоз",
    s: "готовим к вашему времени"
  }, {
    t: "Оплата при получении",
    s: "наличными или картой"
  }, {
    t: "08:00–20:00",
    s: "каждый день"
  }];
  const gallery = ["../../assets/images/atmosphere-1.jpg", "../../assets/images/atmosphere-2.jpg", "../../assets/images/atmosphere-3.jpg", "../../assets/images/atmosphere-4.webp"];
  const reviews = [{
    q: "Постоянно покупаем здесь выпечку и остаёмся в восторге. Качество и разнообразие великолепные, персонал внимательный. Спасибо за вкусную выпечку!",
    n: "Ирина"
  }, {
    q: "Всегда свежая, мягкая, воздушная выпечка, очень вкусные булочки. Цены радуют, а разнообразие впечатляет.",
    n: "Михаил"
  }, {
    q: "Хорошая пекарня! Отличный ассортимент и превосходное качество. Попробуешь раз — вернёшься снова.",
    n: "Дмитрий"
  }];
  return /*#__PURE__*/React.createElement("main", null, /*#__PURE__*/React.createElement("section", {
    className: "tp-hero"
  }, /*#__PURE__*/React.createElement("div", {
    className: "tp-hero-content"
  }, /*#__PURE__*/React.createElement("p", {
    className: "tp-eyebrow tp-eyebrow--sand"
  }, "\u041F\u0435\u043A\u0430\u0440\u043D\u044F \u0440\u044F\u0434\u043E\u043C \u0441 \u0434\u043E\u043C\u043E\u043C"), /*#__PURE__*/React.createElement("h1", {
    className: "tp-h1"
  }, "\u0425\u043B\u0435\u0431, \u043A\u043E\u0442\u043E\u0440\u044B\u0439 \u0436\u0434\u0443\u0442"), /*#__PURE__*/React.createElement("p", {
    className: "tp-hero-text"
  }, "\u041F\u0435\u0447\u0451\u043C \u043D\u0435\u0431\u043E\u043B\u044C\u0448\u0438\u043C\u0438 \u043F\u0430\u0440\u0442\u0438\u044F\u043C\u0438, \u0447\u0442\u043E\u0431\u044B \u0445\u043B\u0435\u0431 \u0445\u0440\u0443\u0441\u0442\u0435\u043B, \u0432\u044B\u043F\u0435\u0447\u043A\u0430 \u043E\u0441\u0442\u0430\u0432\u0430\u043B\u0430\u0441\u044C \u043D\u0435\u0436\u043D\u043E\u0439, \u0430 \u043A\u043E\u0444\u0435 \u0441\u043E\u0433\u0440\u0435\u0432\u0430\u043B."), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    onClick: () => onNavigate("menu")
  }, "\u0421\u0434\u0435\u043B\u0430\u0442\u044C \u0437\u0430\u043A\u0430\u0437"))), /*#__PURE__*/React.createElement("section", {
    className: "tp-trust"
  }, trust.map(it => /*#__PURE__*/React.createElement("div", {
    className: "tp-trust-item",
    key: it.t
  }, /*#__PURE__*/React.createElement("span", {
    className: "tp-trust-dot",
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("span", {
    className: "tp-trust-copy"
  }, /*#__PURE__*/React.createElement("strong", null, it.t), /*#__PURE__*/React.createElement("span", null, it.s))))), /*#__PURE__*/React.createElement("section", {
    className: "tp-section tp-about"
  }, /*#__PURE__*/React.createElement("div", {
    className: "tp-about-text"
  }, /*#__PURE__*/React.createElement("p", {
    className: "tp-eyebrow"
  }, "\u041E \u043D\u0430\u0441"), /*#__PURE__*/React.createElement("h2", {
    className: "tp-h2"
  }, "\u041F\u0435\u0447\u0451\u043C \u0441 \u0437\u0430\u0431\u043E\u0442\u043E\u0439 \u0438 \u043F\u0440\u043E\u0441\u0442\u044B\u043C\u0438 \u0438\u043D\u0433\u0440\u0435\u0434\u0438\u0435\u043D\u0442\u0430\u043C\u0438"), /*#__PURE__*/React.createElement("p", {
    className: "tp-body"
  }, "\u0413\u043E\u0442\u043E\u0432\u0438\u043C \u0445\u043B\u0435\u0431, \u0434\u0435\u0441\u0435\u0440\u0442\u044B \u0438 \u043D\u0430\u043F\u0438\u0442\u043A\u0438 \u043D\u0435\u0431\u043E\u043B\u044C\u0448\u0438\u043C\u0438 \u043F\u0430\u0440\u0442\u0438\u044F\u043C\u0438, \u0447\u0442\u043E\u0431\u044B \u043A\u0430\u0436\u0434\u044B\u0439 \u0433\u043E\u0441\u0442\u044C \u043F\u043E\u043B\u0443\u0447\u0430\u043B \u0441\u0432\u0435\u0436\u0438\u0439 \u0432\u043A\u0443\u0441. \u0412 \u043E\u0441\u043D\u043E\u0432\u0435 \u0440\u0430\u0431\u043E\u0442\u044B \u2014 \u043D\u0430\u0442\u0443\u0440\u0430\u043B\u044C\u043D\u044B\u0435 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u044B, \u0441\u043F\u043E\u043A\u043E\u0439\u043D\u0430\u044F \u0430\u0442\u043C\u043E\u0441\u0444\u0435\u0440\u0430 \u0438 \u043B\u044E\u0431\u043E\u0432\u044C \u043A \u0445\u043E\u0440\u043E\u0448\u0435\u0439 \u0432\u044B\u043F\u0435\u0447\u043A\u0435.")), /*#__PURE__*/React.createElement("div", {
    className: "tp-about-card"
  }, /*#__PURE__*/React.createElement("strong", null, "08:00"), /*#__PURE__*/React.createElement("span", null, "\u043F\u0435\u0440\u0432\u0430\u044F \u043F\u0430\u0440\u0442\u0438\u044F \u0445\u043B\u0435\u0431\u0430 \u0443\u0436\u0435 \u043D\u0430 \u0432\u0438\u0442\u0440\u0438\u043D\u0435"))), /*#__PURE__*/React.createElement("section", {
    className: "tp-section tp-section--band"
  }, /*#__PURE__*/React.createElement("div", {
    className: "tp-section-head"
  }, /*#__PURE__*/React.createElement("p", {
    className: "tp-eyebrow"
  }, "\u0413\u0430\u043B\u0435\u0440\u0435\u044F"), /*#__PURE__*/React.createElement("h2", {
    className: "tp-h2"
  }, "\u0410\u0442\u043C\u043E\u0441\u0444\u0435\u0440\u0430 \u043F\u0435\u043A\u0430\u0440\u043D\u0438")), /*#__PURE__*/React.createElement("div", {
    className: "tp-gallery"
  }, gallery.map((src, i) => /*#__PURE__*/React.createElement("img", {
    key: i,
    src: src,
    alt: "",
    loading: "lazy"
  })))), /*#__PURE__*/React.createElement("section", {
    className: "tp-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "tp-section-head"
  }, /*#__PURE__*/React.createElement("p", {
    className: "tp-eyebrow"
  }, "\u041E\u0442\u0437\u044B\u0432\u044B"), /*#__PURE__*/React.createElement("h2", {
    className: "tp-h2"
  }, "\u0427\u0442\u043E \u0433\u043E\u0432\u043E\u0440\u044F\u0442 \u0433\u043E\u0441\u0442\u0438")), /*#__PURE__*/React.createElement("div", {
    className: "tp-reviews"
  }, reviews.map(r => /*#__PURE__*/React.createElement("blockquote", {
    className: "tp-review",
    key: r.n
  }, /*#__PURE__*/React.createElement("p", null, "\u201C", r.q, "\u201D"), /*#__PURE__*/React.createElement("cite", null, r.n))))), /*#__PURE__*/React.createElement("section", {
    className: "tp-section tp-section--band tp-contacts"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    className: "tp-eyebrow"
  }, "\u041A\u043E\u043D\u0442\u0430\u043A\u0442\u044B"), /*#__PURE__*/React.createElement("h2", {
    className: "tp-h2"
  }, "\u0417\u0430\u0433\u043B\u044F\u0434\u044B\u0432\u0430\u0439\u0442\u0435 \u0437\u0430 \u0441\u0432\u0435\u0436\u0435\u0439 \u0432\u044B\u043F\u0435\u0447\u043A\u043E\u0439")), /*#__PURE__*/React.createElement("div", {
    className: "tp-contact-list"
  }, /*#__PURE__*/React.createElement("p", null, /*#__PURE__*/React.createElement("strong", null, "\u0410\u0434\u0440\u0435\u0441:"), " \u0420\u043E\u0441\u0442\u043E\u0432\u0441\u043A\u0430\u044F \u043E\u0431\u043B., \u0441\u043B. \u0420\u043E\u0434\u0438\u043E\u043D\u043E\u0432\u043E-\u041D\u0435\u0441\u0432\u0435\u0442\u0430\u0439\u0441\u043A\u0430\u044F, \u0443\u043B. \u0411\u0430\u0431\u0438\u0447\u0435\u0432\u0430, 51"), /*#__PURE__*/React.createElement("p", null, /*#__PURE__*/React.createElement("strong", null, "\u0422\u0435\u043B\u0435\u0444\u043E\u043D:"), " +7 (929) 816-70-09"), /*#__PURE__*/React.createElement("p", null, /*#__PURE__*/React.createElement("strong", null, "\u0427\u0430\u0441\u044B \u0440\u0430\u0431\u043E\u0442\u044B:"), " \u0435\u0436\u0435\u0434\u043D\u0435\u0432\u043D\u043E, 08:00\u201320:00"))));
}
window.HomeView = HomeView;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/HomeView.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/MenuView.jsx
try { (() => {
// MenuView — sticky category rail + product grid (uses ProductCard).
function MenuView({
  cart,
  onAdd,
  onSetQty
}) {
  const {
    ProductCard
  } = window.DesignSystem_0db2f9;
  const products = window.BAKERY_PRODUCTS;
  const categories = window.BAKERY_CATEGORIES;
  const [active, setActive] = React.useState("all");
  const shown = active === "all" ? products : products.filter(p => p.category === active);
  const title = active === "all" ? "Весь ассортимент" : categories.find(c => c.id === active).label;
  return /*#__PURE__*/React.createElement("main", {
    className: "tp-menu"
  }, /*#__PURE__*/React.createElement("nav", {
    className: "tp-cat-rail",
    "aria-label": "\u041A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0438 \u043C\u0435\u043D\u044E"
  }, categories.map(c => /*#__PURE__*/React.createElement("button", {
    key: c.id,
    type: "button",
    className: "tp-cat-card" + (active === c.id ? " is-active" : ""),
    onClick: () => setActive(active === c.id ? "all" : c.id)
  }, /*#__PURE__*/React.createElement("img", {
    src: c.icon,
    alt: "",
    width: "52",
    height: "52"
  }), /*#__PURE__*/React.createElement("span", null, c.label)))), /*#__PURE__*/React.createElement("section", {
    className: "tp-catalog"
  }, /*#__PURE__*/React.createElement("div", {
    className: "tp-catalog-head"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    className: "tp-eyebrow"
  }, "\u0421\u0435\u0433\u043E\u0434\u043D\u044F \u043D\u0430 \u0432\u0438\u0442\u0440\u0438\u043D\u0435"), /*#__PURE__*/React.createElement("h1", {
    className: "tp-h2",
    style: {
      marginTop: 4
    }
  }, title))), /*#__PURE__*/React.createElement("div", {
    className: "tp-product-grid"
  }, shown.map(p => /*#__PURE__*/React.createElement(ProductCard, {
    key: p.id,
    name: p.name,
    description: p.description,
    price: p.price,
    image: p.image,
    stock: p.stock,
    compact: true,
    quantity: cart[p.id] || 0,
    onAdd: () => onAdd(p.id),
    onChange: n => onSetQty(p.id, n)
  })))));
}
window.MenuView = MenuView;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/MenuView.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/app.jsx
try { (() => {
// App — orchestrates view switching + cart state.
function App() {
  const [view, setView] = React.useState("home");
  const [cart, setCart] = React.useState({});
  const [cartOpen, setCartOpen] = React.useState(false);
  const addToCart = id => setCart(c => ({
    ...c,
    [id]: (c[id] || 0) + 1
  }));
  const setQty = (id, n) => setCart(c => {
    const next = {
      ...c
    };
    if (n <= 0) delete next[id];else next[id] = n;
    return next;
  });
  const cartCount = Object.values(cart).reduce((s, q) => s + q, 0);
  const navigate = id => {
    if (id === "gallery" || id === "contacts") {
      setView("home");
      requestAnimationFrame(() => {
        const el = document.querySelector(id === "gallery" ? ".tp-gallery" : ".tp-contacts");
        if (el) window.scrollTo({
          top: el.getBoundingClientRect().top + window.scrollY - 90,
          behavior: "smooth"
        });
      });
    } else {
      setView(id);
      window.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(window.Header, {
    view: view,
    onNavigate: navigate,
    cartCount: cartCount,
    onOpenCart: () => setCartOpen(true)
  }), view === "menu" ? /*#__PURE__*/React.createElement(window.MenuView, {
    cart: cart,
    onAdd: addToCart,
    onSetQty: setQty
  }) : /*#__PURE__*/React.createElement(window.HomeView, {
    onNavigate: navigate
  }), /*#__PURE__*/React.createElement("footer", {
    className: "tp-footer"
  }, /*#__PURE__*/React.createElement("strong", null, "\u0422\u0451\u043F\u043B\u0430\u044F \u043F\u0435\u043A\u0430\u0440\u043D\u044F"), /*#__PURE__*/React.createElement("p", null, "\xA9 2026. \u0421\u0432\u0435\u0436\u0430\u044F \u0432\u044B\u043F\u0435\u0447\u043A\u0430 \u043A\u0430\u0436\u0434\u044B\u0439 \u0434\u0435\u043D\u044C.")), /*#__PURE__*/React.createElement(window.CartDrawer, {
    open: cartOpen,
    cart: cart,
    onClose: () => setCartOpen(false),
    onSetQty: setQty
  }));
}
ReactDOM.createRoot(document.getElementById("root")).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/products.js
try { (() => {
// Тёплая пекарня — demo catalog data for the UI kit.
// Photos are reused from the brand asset set; prices/stock mirror the real shop.
window.BAKERY_PRODUCTS = [{
  id: "bread-1",
  category: "bread",
  name: "Хлеб пшеничный",
  price: 55,
  stock: 8,
  image: "../../assets/images/atmosphere-4.webp",
  description: "Хрустящая корочка и мягкий мякиш — печём первой партией к 08:00."
}, {
  id: "bread-2",
  category: "bread",
  name: "Деревенский на закваске",
  price: 95,
  stock: 4,
  image: "../../assets/images/hero-bakery.webp",
  description: "Долгое брожение, плотный мякиш и насыщенный вкус зерна."
}, {
  id: "pastry-1",
  category: "pastry",
  name: "Хачапури с сыром",
  price: 75,
  stock: 5,
  image: "../../assets/images/bakery-1.jfif",
  description: "Сочная сырная начинка в нежном тесте — берут ещё тёплым."
}, {
  id: "pastry-2",
  category: "pastry",
  name: "Самса с курицей",
  price: 85,
  stock: 11,
  image: "../../assets/images/bakery-2.jfif",
  description: "Плотное слоёное тесто, ароматная курица и немного специй."
}, {
  id: "pastry-3",
  category: "pastry",
  name: "Сосиска в тесте",
  price: 60,
  stock: 0,
  image: "../../assets/images/bakery-1.jfif",
  description: "Нежное тесто и сочная сосиска для быстрого перекуса."
}, {
  id: "dessert-1",
  category: "desserts",
  name: "Корзиночка с кремом",
  price: 90,
  stock: 7,
  image: "../../assets/images/bakery-2.jfif",
  description: "Песочная корзиночка с воздушным заварным кремом."
}, {
  id: "drink-1",
  category: "drinks",
  name: "Капучино",
  price: 140,
  stock: 30,
  image: "../../assets/images/atmosphere-4.webp",
  description: "На зерне свежей обжарки — согревает в любую погоду."
}];
window.BAKERY_CATEGORIES = [{
  id: "bread",
  label: "Хлеб",
  icon: "../../assets/icons/nav-bread.svg"
}, {
  id: "pastry",
  label: "Выпечка",
  icon: "../../assets/icons/nav-pastry.svg"
}, {
  id: "desserts",
  label: "Десерты",
  icon: "../../assets/icons/nav-desserts.svg"
}, {
  id: "drinks",
  label: "Напитки",
  icon: "../../assets/icons/nav-drinks.svg"
}];
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/products.js", error: String((e && e.message) || e) }); }

__ds_ns.Wordmark = __ds_scope.Wordmark;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.QuantityControl = __ds_scope.QuantityControl;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.CategoryTab = __ds_scope.CategoryTab;

__ds_ns.Price = __ds_scope.Price;

__ds_ns.ProductCard = __ds_scope.ProductCard;

__ds_ns.Input = __ds_scope.Input;

})();
