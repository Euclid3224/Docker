# Тёплая пекарня — Design System

A design system for **«Тёплая пекарня»** (Warm Bakery) — a neighbourhood artisan bakery in
sloboda Rodionovo-Nesvetayskaya, Rostov region. The shop sells bread, pastry, desserts and
drinks, baked in small batches, with pickup orders and pay-on-collection. The tagline is
**«Свежая выпечка каждый день»** (Fresh baking every day).

This system captures the warm, edible, unhurried character of the brand and packages it as
reusable tokens, components and a full website UI kit — so any new page, slide or mockup can
be produced on-brand in minutes.

## Sources
Built by reading the brand's own codebase (attached as a local folder):
- `bakery-current-main/Docker-main/app/` — the live site: `index.html`, `menu.html`,
  `style.css` (4.5k lines), `catalog.js`, product data, admin panel.
- `…/app/assets/` — Cormorant Garamond variable fonts, category & UI icons, photography.
- `…/Docker-main/design-qa.md` — the redesign brief & QA notes.
- GitHub: **Euclid3224/Docker** — the same project's repository. Explore it to recreate
  pages more faithfully or to pull additional assets.

Reference screenshots of the current site live in `_ref/` (desktop + mobile, home + menu).

---

## What the user asked for
> «В целом готовый сайт. Нужно улучшить дизайн, поработать со шрифтом, чтобы всё хорошо
> читалось и с компьютера, и с телефона. Все иконки и надписи были ровными.»

**The key improvement made here:** the original site set *everything*, including body copy,
in Cormorant Garamond. An elegant serif is beautiful for display, but it hurts readability at
small sizes — especially on phones. This system keeps **Cormorant Garamond for display**
(headings, the wordmark, big numbers) and introduces **Nunito Sans** — a warm humanist sans
with full Cyrillic — for **all body text, UI labels, prices and buttons**. Icons and labels are
aligned with `flex`/`grid` + `gap`, never loose inline flow.

---

## CONTENT FUNDAMENTALS — how the bakery writes

- **Language:** Russian only. Warm, calm, hospitable — never salesy or loud.
- **Voice:** «мы» about the bakery, «вы / вас» about the guest («готовим к вашему времени»,
  «заглядывайте за свежей выпечкой»). Inviting, not commanding.
- **Tone:** sensory and homely — words like *хрустел, нежной, согревал, небольшими партиями,
  с заботой*. Emphasis on freshness, small batches, natural ingredients, a cozy room.
- **Casing:** sentence case everywhere. Headings are short and evocative («Хлеб, который ждут»,
  «Атмосфера пекарни»). Eyebrows are the **only** uppercase text («О НАС», «ГАЛЕРЕЯ»,
  «СЕГОДНЯ НА ВИТРИНЕ») and act as section kickers above a serif headline.
- **Microcopy:** plain and practical — «Самовывоз», «Оплата при получении», «В корзину»,
  «Весь ассортимент», «Нет в наличии», «Когда планируете забрать».
- **Numbers:** prices in roubles with the «₽» glyph («75 ₽»); hours as «08:00–20:00»;
  stock as «В наличии: 11 шт.».
- **Emoji:** none. Punctuation uses «ёлочки» quotes and em/en dashes. The letter **ё** is
  written explicitly («Тёплая», «печём»).

---

## VISUAL FOUNDATIONS

- **Palette (warm & edible):** cream/porcelain/milk surfaces, a brown ramp from `gold` →
  `caramel` → `cocoa` → `coffee`, with **caramel `#b87538`** as the single primary action
  colour. One olive-green accent (`leaf #6f7f4d`) is reserved for prices and "in stock";
  berry (`#8e3a2c`) only for errors / sold-out. No blues, no purple gradients. See `tokens/colors.css`.
- **Type:** Cormorant Garamond (display, often italic for the wordmark) + Nunito Sans (everything
  else). Fluid `clamp()` display scale; 17px base body for comfortable Cyrillic. See `tokens/typography.css`.
- **Backgrounds:** a soft cream→wheat vertical gradient with a faint gold radial glow top-left.
  Tinted "band" sections use the `milk` colour. Hero & menu-hero use **full-bleed photography**
  with a left→right dark **protection gradient** so white text stays legible.
- **Imagery:** warm, golden, appetising photos of bread and the shop interior — natural light,
  no heavy filters, no black & white. Product shots are framed slightly low (`object-position: center 25%`).
- **Corners:** `8px` cards / inputs, `12px` catalog cards & panels, `18px` the hero split-card,
  fully-rounded **pills** (`999px`) for buttons, tabs, badges and prices.
- **Cards:** light porcelain/white fill, a hairline `border-soft`, and a soft **warm brown
  shadow** (never grey). Hover lifts the card (`translateY(-6px)`), deepens the shadow and
  gently zooms the photo.
- **Shadows:** brown-tinted, layered: `--shadow-sm` (sticky bars / chips), `--shadow` (cards),
  `--shadow-hover`, `--shadow-button` (caramel CTAs). See `tokens/spacing.css`.
- **Borders & hairlines:** `1px` `rgba(86,48,31,.12)`; decorative gold hairlines
  (`linear-gradient(90deg, transparent, gold, transparent)`) separate card head from body.
- **Transparency & blur:** the sticky header is `cream @ 82%` with `backdrop-filter: blur(18px)`;
  the cart backdrop is `coffee @ 50%`.
- **Motion:** quick and gentle — `0.2–0.25s` ease for hovers, `0.45s` for image zooms. Buttons
  **lift + brighten** on hover; pressed/disabled states **desaturate** and drop the lift. No
  bounces, no infinite decorative loops. Focus shows a 3px gold outline.
- **Layout:** sticky header; fluid section padding `clamp(72px,9vw,122px)` with a
  `clamp(20px,5vw,84px)` gutter; content max ~1320px. Catalog 3-up → 2-up → 1-up; trust strip
  and reviews collapse to a single column on mobile.

---

## ICONOGRAPHY

- **Category icons** (`assets/icons/nav-bread/pastry/desserts/drinks.svg`) are the brand's own
  flat SVGs — a caramel glyph on a soft rounded `sand` tile. Used in the menu category rail and
  the cart toggle (`nav-cart.svg`). **Copy these in and reference them; never redraw.**
- **UI icons** (`icon-search.svg`, `icon-menu.svg`, `icon-close.svg`) are simple monochrome
  line icons matching the cocoa text colour.
- The original site also used a few inline single-stroke SVGs in the trust strip (basket / card /
  clock). In this system that strip uses a small caramel **dot** marker instead, to keep icon
  weight consistent — swap in line icons of matching stroke if you prefer.
- **No emoji, no icon font.** If you need an icon not in the set, add an SVG of the same flat,
  rounded, single-weight style (or a close Lucide match) and document it here.
- All icons are sized in even px steps and centred with `grid`/`place-items` so they sit on the
  text baseline — addressing the "иконки и надписи ровные" request.

---

## Substitutions / flags
- **Nunito Sans** is loaded from Google Fonts (it was not in the codebase). If the bakery has a
  preferred body typeface, drop the files into `assets/fonts/` and update `tokens/typography.css`.
- **Cormorant Garamond** ships locally (the project's own licensed variable fonts, OFL — see
  `assets/fonts/OFL.txt`). The original logo's exact proprietary face was never provided;
  Cormorant is the confirmed close match per `design-qa.md`.

---

## Index / manifest

**Root**
- `styles.css` — single entry point (imports only); consumers link this.
- `tokens/colors.css` · `tokens/typography.css` · `tokens/spacing.css` — design tokens + `@font-face`.
- `readme.md` (this file) · `SKILL.md` — guide & Agent-Skill manifest.
- `assets/` — `fonts/`, `icons/`, `images/`.
- `_ref/` — reference screenshots of the live site.

**Foundation cards** (`guidelines/`, shown in the Design System tab)
- Type: display, body, pairing · Colors: surfaces, brand, accents · Spacing: scale, radii,
  shadows · Brand: wordmark, category icons, hero treatment.

**Components** (`components/`)
- `buttons/` — **Button**, **IconButton**, **QuantityControl**
- `forms/` — **Input**
- `commerce/` — **Badge**, **Price**, **CategoryTab**, **ProductCard**
- `brand/` — **Wordmark**

Each has a `.jsx`, a `.d.ts` props contract, a `.prompt.md` usage note, and a directory card.

**UI Kit** (`ui_kits/website/`)
- Interactive recreation of the bakery website (home + menu + cart). See its `README.md`.

> Components are exposed at runtime under `window.DesignSystem_0db2f9`. In a card/screen, load
> `_ds_bundle.js` then `const { Button, ProductCard } = window.DesignSystem_0db2f9`.
